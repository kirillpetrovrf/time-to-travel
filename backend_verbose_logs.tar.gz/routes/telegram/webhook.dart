import 'dart:convert';
import 'package:dart_frog/dart_frog.dart';
import 'package:backend/services/database_service.dart';
import 'package:backend/services/telegram_bot_service.dart';
import 'package:backend/repositories/user_repository.dart';
import 'package:logging/logging.dart';

final _log = Logger('TelegramWebhook');

/// Обработчик Telegram webhook
Future<Response> onRequest(RequestContext context) async {
  if (context.request.method != HttpMethod.post) {
    return Response(statusCode: 405, body: 'Method Not Allowed');
  }

  try {
    _log.info('🌐 [WEBHOOK] ========== ПОЛУЧЕН ЗАПРОС ОТ TELEGRAM ==========');
    
    final body = await context.request.body();
    _log.info('📦 [WEBHOOK] Body: $body');
    
    final update = jsonDecode(body) as Map<String, dynamic>;
    _log.info('📱 [WEBHOOK] Update parsed: ${update.keys.join(', ')}');

    // Получаем сервисы из контекста
    final db = context.read<DatabaseService>();
    final userRepo = UserRepository(db);
    final telegramBot = context.read<TelegramBotService>();

    // Обработка сообщения
    if (update['message'] != null) {
      final message = update['message'] as Map<String, dynamic>;
      _log.info('💬 [WEBHOOK] Получено сообщение: ${message['text']}');
      
      final text = message['text'] as String?;
      final from = message['from'] as Map<String, dynamic>;
      final chatId = from['id'] as int;
      
      _log.info('👤 [WEBHOOK] От пользователя: chatId=$chatId, username=${from['username']}, firstName=${from['first_name']}');

      if (text != null && text.startsWith('/start')) {
        _log.info('🚀 [WEBHOOK] Обнаружена команда /start: $text');
        
        await _handleStartCommand(
          text: text,
          chatId: chatId,
          from: from,
          userRepo: userRepo,
          telegramBot: telegramBot,
        );
      } else {
        _log.info('ℹ️ [WEBHOOK] Команда НЕ /start, игнорируем: $text');
      }
    } else {
      _log.info('ℹ️ [WEBHOOK] Update без message, пропускаем');
    }

    _log.info('✅ [WEBHOOK] Обработка завершена успешно');
    return Response(statusCode: 200, body: 'OK');
  } catch (e, stackTrace) {
    _log.severe('❌ [WEBHOOK] КРИТИЧЕСКАЯ ОШИБКА: $e', e, stackTrace);
    return Response(statusCode: 500, body: 'Internal Server Error');
  }
}

/// Обработка команды /start
Future<void> _handleStartCommand({
  required String text,
  required int chatId,
  required Map<String, dynamic> from,
  required UserRepository userRepo,
  required TelegramBotService telegramBot,
}) async {
  _log.info('🎯 [START] ========== ОБРАБОТКА КОМАНДЫ /start ==========');
  _log.info('📝 [START] Полный текст: $text');
  
  final telegramId = chatId;
  final firstName = from['first_name'] as String?;
  final lastName = from['last_name'] as String?;
  final username = from['username'] as String?;
  
  _log.info('👤 [START] Данные пользователя: telegramId=$telegramId, firstName=$firstName, lastName=$lastName, username=$username');

  // Проверяем есть ли параметр (deep link)
  final parts = text.split(' ');
  _log.info('🔍 [START] Разбор команды: найдено частей: ${parts.length}');
  
  String? authCode;
  String? phone;

  if (parts.length > 1) {
    authCode = parts[1]; // например: AUTH_79281234567
    _log.info('🔑 [START] Обнаружен параметр: $authCode');
    
    if (authCode.startsWith('AUTH_')) {
      phone = '+${authCode.substring(5)}'; // Убираем AUTH_
      _log.info('� [START] Извлечён телефон из authCode: $phone');
    } else {
      _log.warning('⚠️ [START] Параметр НЕ начинается с AUTH_: $authCode');
    }
  } else {
    _log.info('ℹ️ [START] Команда без параметров (обычный /start)');
  }

  try {
    _log.info('💾 [START] Вызываем upsertFromTelegram с phone=$phone, telegramId=$telegramId');
    
    // Создаём или обновляем пользователя
    final user = await userRepo.upsertFromTelegram(
      telegramId: telegramId,
      phone: phone,
      firstName: firstName,
      lastName: lastName,
      username: username,
    );

    _log.info('✅ [START] Пользователь обработан: id=${user.id}, phone=${user.phone}, telegram_id=${user.telegramId}');

    // Если это авторизация через deep link
    if (authCode != null) {
      // Сохраняем статус авторизации (для polling)
      // TODO: Сохранить в Redis или временную таблицу
      // authSessions[authCode] = {userId: user.id, status: 'success'}

      // Отправляем приветствие
      await telegramBot.sendMessage(
        chatId: chatId,
        text: '''
🎉 <b>Добро пожаловать в TimeToTravel!</b>

Вы успешно авторизовались!

Теперь можете вернуться в приложение и начать пользоваться сервисом.

👉 Закройте Telegram и откройте приложение
''',
      );
    } else {
      // Обычный /start без параметров
      final greeting = user.isDispatcher
          ? '''
👋 Здравствуйте, <b>${user.fullName}</b>!

Вы зашли как <b>Диспетчер</b>.

📱 Откройте приложение Time To Travel для управления заказами.
'''
          : '''
👋 Здравствуйте, <b>${user.fullName}</b>!

Добро пожаловать в TimeToTravel!

🚗 Откройте приложение для бронирования поездок.
''';

      await telegramBot.sendMessage(chatId: chatId, text: greeting);
    }
  } catch (e) {
    _log.severe('❌ Ошибка обработки /start: $e');
    
    await telegramBot.sendMessage(
      chatId: chatId,
      text: '❌ Произошла ошибка. Попробуйте позже.',
    );
  }
}
