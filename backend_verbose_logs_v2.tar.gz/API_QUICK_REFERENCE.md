# 🎯 Time to Travel API - Полный список endpoints

**Версия:** 1.0.0  
**База данных:** PostgreSQL  
**Аутентификация:** JWT (Access + Refresh tokens)  
**Всего endpoints:** 17

---

## 📋 Быстрый справочник

### 🔐 Аутентификация (6 endpoints)

| Endpoint | Метод | Auth | Описание |
|----------|-------|------|----------|
| `/auth/register` | POST | ❌ | Регистрация нового пользователя |
| `/auth/login` | POST | ❌ | Вход в систему |
| `/auth/me` | GET | ✅ Access | Получить текущего пользователя |
| `/auth/refresh` | POST | ✅ Refresh | Обновить access token |
| `/auth/logout` | POST | ✅ Refresh | Выход (отзыв одного токена) |
| `/auth/logout-all` | POST | ✅ Access | Выход со всех устройств |

---

### 🗺️ Маршруты (1 endpoint)

| Endpoint | Метод | Auth | Описание |
|----------|-------|------|----------|
| `/routes` | GET | ❌ | Поиск/список маршрутов |

**Query params:** `?from=Ростов&to=Таганрог`

---

### 🚕 Заказы (5 endpoints)

| Endpoint | Метод | Auth | Описание |
|----------|-------|------|----------|
| `/orders` | GET | 🔶 Optional | Список заказов (свои или по телефону) |
| `/orders` | POST | 🔶 Optional | Создать заказ |
| `/orders/:id` | GET | 🔶 Optional | Детали заказа |
| `/orders/:id` | PUT | ✅ Access | Обновить заказ |
| `/orders/:id` | DELETE | ✅ Access | Отменить заказ |
| `/orders/:id/status` | PATCH | ✅ Admin/Driver | Изменить статус заказа |

**Query params для GET /orders:** `?phone=...`, `?status=...`, `?limit=...`

---

### 👨‍💼 Админ-панель (4 endpoints)

| Endpoint | Метод | Auth | Описание |
|----------|-------|------|----------|
| `/admin/routes` | POST | ✅ Admin | Создать маршрут |
| `/admin/routes/:id` | PUT | ✅ Admin | Обновить маршрут |
| `/admin/routes/:id` | DELETE | ✅ Admin | Удалить маршрут |
| `/admin/stats` | GET | ✅ Admin | Статистика заказов |

---

### 🏥 Здоровье (1 endpoint)

| Endpoint | Метод | Auth | Описание |
|----------|-------|------|----------|
| `/health` | GET | ❌ | Проверка работоспособности |

---

## 🎭 Роли и доступ

### Client (клиент)
- ✅ Создание и просмотр своих заказов
- ✅ Обновление и отмена своих заказов
- ❌ Изменение статусов
- ❌ Управление маршрутами

### Driver (водитель)
- ✅ Изменение статусов заказов (кроме отмены)
- ❌ Отмена заказов
- ❌ Управление маршрутами

### Admin (администратор)
- ✅ Полный доступ ко всем заказам
- ✅ Управление маршрутами (CRUD)
- ✅ Просмотр статистики
- ✅ Изменение любых статусов

---

## 🔑 Токены

### Access Token
- **Срок:** 1 час
- **Использование:** `Authorization: Bearer <token>`
- **Для:** Доступа к защищенным endpoints

### Refresh Token
- **Срок:** 7 дней
- **Использование:** POST /auth/refresh или /auth/logout
- **Для:** Обновления access token без re-login

---

## 📊 Статусы заказов

| Статус | Описание | Доступные переходы |
|--------|----------|-------------------|
| `pending` | Ожидает подтверждения | → confirmed, cancelled |
| `confirmed` | Подтвержден | → in_progress, cancelled |
| `in_progress` | Выполняется | → completed, cancelled |
| `completed` | Завершен | ✖️ (финальный) |
| `cancelled` | Отменен | ✖️ (финальный) |

---

## 🚗 Классы транспорта

- `economy` - Эконом
- `comfort` - Комфорт
- `business` - Бизнес
- `minivan` - Минивэн

---

## 📦 Размеры багажа

- `S` - Малый (бесплатно для Комфорт/Бизнес)
- `M` - Средний
- `L` - Большой
- `XL` - Очень большой

---

## 🎯 Быстрый старт

### 1. Регистрация
```bash
curl -X POST http://localhost:8080/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"test123","name":"Test","phone":"+79001234567"}'
```

### 2. Получить маршруты
```bash
curl http://localhost:8080/routes?from=Ростов&to=Таганрог
```

### 3. Создать заказ
```bash
curl -X POST http://localhost:8080/orders \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d @order.json
```

### 4. Обновить access token
```bash
curl -X POST http://localhost:8080/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{"refreshToken":"<refresh_token>"}'
```

---

## 📝 Response Codes

| Код | Описание |
|-----|----------|
| 200 | OK - Успех |
| 201 | Created - Ресурс создан |
| 400 | Bad Request - Неверные данные |
| 401 | Unauthorized - Требуется авторизация |
| 403 | Forbidden - Доступ запрещен |
| 404 | Not Found - Не найдено |
| 409 | Conflict - Конфликт (дубликат) |
| 500 | Internal Error - Ошибка сервера |

---

## 🔗 Ссылки

- **Полная документация:** [API_ENDPOINTS.md](./API_ENDPOINTS.md)
- **Orders & Admin отчет:** [ORDERS_ADMIN_API_COMPLETE.md](./ORDERS_ADMIN_API_COMPLETE.md)
- **Auth отчет:** [AUTH_ENDPOINTS_COMPLETE.md](./AUTH_ENDPOINTS_COMPLETE.md)
- **Database schema:** [database/init/01-schema.sql](./database/init/01-schema.sql)

---

**Версия API:** 1.0.0  
**Последнее обновление:** 21 января 2026  
**Статус:** ✅ Production Ready
