import 'dart:convert';
import 'package:dart_frog/dart_frog.dart';
import 'package:backend/services/database_service.dart';
import 'package:backend/repositories/user_repository.dart';
import 'package:logging/logging.dart';

final _log = Logger('TelegramInit');

/// POST /auth/telegram/init
/// Начать процесс авторизации через Telegram
Future<Response> onRequest(RequestContext context) async {
  if (context.request.method != HttpMethod.post) {
    return Response(statusCode: 405);
  }

  try {
    final body = await context.request.body();
    final data = jsonDecode(body) as Map<String, dynamic>;
    final phone = data['phone'] as String?;

    if (phone == null || phone.isEmpty) {
      return Response.json(
        statusCode: 400,
        body: {'error': 'Phone number is required'},
      );
    }

    // Очищаем телефон от лишних символов
    final cleanPhone = phone.replaceAll(RegExp(r'[^\d+]'), '');
    
    // Генерируем код авторизации
    final authCode = 'AUTH_${cleanPhone.replaceAll('+', '')}';
    
    // Создаём или находим пользователя по телефону
    final db = context.read<DatabaseService>();
    final userRepo = UserRepository(db);
    
    var user = await userRepo.findByPhone(cleanPhone);
    
    if (user == null) {
      // Создаём временную запись пользователя
      final userId = await db.insert(
        '''
        INSERT INTO users (
          phone, role, is_active, email, password_hash, name
        ) VALUES (
          @phone, 'passenger', true, '', '', 'Новый пользователь'
        )
        ''',
        parameters: {
          'phone': cleanPhone,
        },
      );
      
      _log.info('✅ Создан временный пользователь: id=$userId, phone=$cleanPhone');
    } else {
      _log.info('✅ Найден существующий пользователь: id=${user.id}, phone=$cleanPhone');
    }
    
    // Формируем deep link
    final deepLink = 'https://t.me/timetotravelauth_bot?start=$authCode';

    return Response.json(
      body: {
        'deepLink': deepLink,
        'authCode': authCode,
        'phone': cleanPhone,
      },
    );
  } catch (e, stackTrace) {
    _log.severe('❌ Ошибка при инициализации Telegram авторизации: $e', e, stackTrace);
    return Response.json(
      statusCode: 500,
      body: {'error': 'Internal server error'},
    );
  }
}
