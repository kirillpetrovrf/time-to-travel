import 'dart:convert';
import 'package:dart_frog/dart_frog.dart';

/// POST /auth/telegram/init
/// Начать процесс авторизации через Telegram
Future<Response> onRequest(RequestContext context) async {
  if (context.request.method != HttpMethod.post) {
    return Response(statusCode: 405);
  }

  try {
    final body = await context.request.body();
    final data = jsonDecode(body) as Map<String, dynamic>;
    final phone = data['phone'] as String?;

    if (phone == null || phone.isEmpty) {
      return Response.json(
        statusCode: 400,
        body: {'error': 'Phone number is required'},
      );
    }

    // Очищаем телефон от лишних символов
    final cleanPhone = phone.replaceAll(RegExp(r'[^\d+]'), '');
    
    // Генерируем код авторизации
    final authCode = 'AUTH_${cleanPhone.replaceAll('+', '')}';
    
    // Формируем deep link
    final deepLink = 'https://t.me/timetotravelauth_bot?start=$authCode';

    return Response.json(
      body: {
        'deepLink': deepLink,
        'authCode': authCode,
        'phone': cleanPhone,
      },
    );
  } catch (e) {
    return Response.json(
      statusCode: 500,
      body: {'error': 'Internal server error'},
    );
  }
}
