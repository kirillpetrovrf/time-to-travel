import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import '../services/yandex_maps_service.dart';

/// Поле ввода адреса с автозаполнением через Yandex Suggest API
class AddressAutocompleteField extends StatefulWidget {
  final TextEditingController controller;
  final String placeholder;
  final IconData prefixIcon;
  final Color iconColor;
  final Color backgroundColor;
  final Color textColor;
  final Color placeholderColor;
  final void Function(String)? onAddressSelected;

  const AddressAutocompleteField({
    super.key,
    required this.controller,
    required this.placeholder,
    required this.prefixIcon,
    required this.iconColor,
    required this.backgroundColor,
    required this.textColor,
    required this.placeholderColor,
    this.onAddressSelected,
  });

  @override
  State<AddressAutocompleteField> createState() =>
      _AddressAutocompleteFieldState();
}

class _AddressAutocompleteFieldState extends State<AddressAutocompleteField> {
  final YandexMapsService _mapsService = YandexMapsService.instance;
  List<String> _suggestions = [];
  bool _isLoading = false;
  Timer? _debounceTimer;
  final LayerLink _layerLink = LayerLink();
  OverlayEntry? _overlayEntry;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onTextChanged);
    _debounceTimer?.cancel();
    _removeOverlay();
    super.dispose();
  }

  void _onTextChanged() {
    final text = widget.controller.text;

    // Отменяем предыдущий таймер
    _debounceTimer?.cancel();

    if (text.length < 2) {
      _removeOverlay();
      return;
    }

    // Устанавливаем новый таймер (debounce 500ms)
    _debounceTimer = Timer(const Duration(milliseconds: 500), () {
      _fetchSuggestions(text);
    });
  }

  Future<void> _fetchSuggestions(String query) async {
    if (!mounted) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final suggestions = await _mapsService.getSuggestions(query);

      if (!mounted) return;

      setState(() {
        _suggestions = suggestions;
        _isLoading = false;
      });

      if (_suggestions.isNotEmpty) {
        _showOverlay();
      } else {
        _removeOverlay();
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
        _suggestions = [];
      });
      _removeOverlay();
    }
  }

  void _showOverlay() {
    _removeOverlay();

    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        width:
            MediaQuery.of(context).size.width -
            32, // Отступы 16 с каждой стороны
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: const Offset(0, 70), // Смещение вниз от поля ввода
          child: Material(
            elevation: 8,
            borderRadius: BorderRadius.circular(12),
            color: widget.backgroundColor,
            child: Container(
              constraints: const BoxConstraints(maxHeight: 200),
              decoration: BoxDecoration(
                color: widget.backgroundColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: CupertinoColors.separator.withOpacity(0.3),
                  width: 0.5,
                ),
              ),
              child: ListView.separated(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                itemCount: _suggestions.length,
                separatorBuilder: (context, index) => Divider(
                  height: 1,
                  thickness: 0.5,
                  color: CupertinoColors.separator.withOpacity(0.3),
                ),
                itemBuilder: (context, index) {
                  final suggestion = _suggestions[index];
                  return CupertinoButton(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    onPressed: () {
                      widget.controller.text = suggestion;
                      widget.onAddressSelected?.call(suggestion);
                      _removeOverlay();
                    },
                    child: Row(
                      children: [
                        Icon(
                          CupertinoIcons.location,
                          size: 16,
                          color: widget.iconColor.withOpacity(0.7),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            suggestion,
                            style: TextStyle(
                              fontSize: 14,
                              color: widget.textColor,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );

    Overlay.of(context).insert(_overlayEntry!);
  }

  void _removeOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: Container(
        decoration: BoxDecoration(
          color: widget.backgroundColor,
          borderRadius: BorderRadius.circular(12),
        ),
        child: CupertinoTextField(
          controller: widget.controller,
          placeholder: widget.placeholder,
          padding: const EdgeInsets.all(16),
          decoration: null,
          style: TextStyle(color: widget.textColor),
          placeholderStyle: TextStyle(color: widget.placeholderColor),
          suffix: _isLoading
              ? const Padding(
                  padding: EdgeInsets.only(right: 16),
                  child: CupertinoActivityIndicator(radius: 10),
                )
              : null,
          prefix: Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Icon(widget.prefixIcon, color: widget.iconColor, size: 20),
          ),
        ),
      ),
    );
  }
}
