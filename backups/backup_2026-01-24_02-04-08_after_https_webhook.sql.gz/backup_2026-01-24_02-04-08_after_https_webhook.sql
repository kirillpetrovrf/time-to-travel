--
-- PostgreSQL database dump
--

\restrict hPIkhLY3vWMLLAfyhWLF8FEK2oZvTyEfxfWRhayw1uJ6UGubWAkvnnCOLgYkemc

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.predefined_routes DROP CONSTRAINT IF EXISTS predefined_routes_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_order_id_fkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_user_id_fkey;
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_route_groups_updated_at ON public.route_groups;
DROP TRIGGER IF EXISTS update_predefined_routes_updated_at ON public.predefined_routes;
DROP TRIGGER IF EXISTS update_orders_updated_at ON public.orders;
DROP INDEX IF EXISTS public.idx_users_telegram_unique;
DROP INDEX IF EXISTS public.idx_users_role;
DROP INDEX IF EXISTS public.idx_users_phone;
DROP INDEX IF EXISTS public.idx_users_email;
DROP INDEX IF EXISTS public.idx_users_created_at;
DROP INDEX IF EXISTS public.idx_sessions_user;
DROP INDEX IF EXISTS public.idx_sessions_token;
DROP INDEX IF EXISTS public.idx_route_groups_is_active;
DROP INDEX IF EXISTS public.idx_refresh_tokens_user_id;
DROP INDEX IF EXISTS public.idx_refresh_tokens_expires_at;
DROP INDEX IF EXISTS public.idx_predefined_routes_is_active;
DROP INDEX IF EXISTS public.idx_predefined_routes_group_id;
DROP INDEX IF EXISTS public.idx_predefined_routes_cities;
DROP INDEX IF EXISTS public.idx_payments_transaction_id;
DROP INDEX IF EXISTS public.idx_payments_status;
DROP INDEX IF EXISTS public.idx_payments_order_id;
DROP INDEX IF EXISTS public.idx_orders_user_id;
DROP INDEX IF EXISTS public.idx_orders_trip_type;
DROP INDEX IF EXISTS public.idx_orders_status;
DROP INDEX IF EXISTS public.idx_orders_pets;
DROP INDEX IF EXISTS public.idx_orders_passengers;
DROP INDEX IF EXISTS public.idx_orders_order_id;
DROP INDEX IF EXISTS public.idx_orders_direction;
DROP INDEX IF EXISTS public.idx_orders_departure_date;
DROP INDEX IF EXISTS public.idx_orders_created_at;
DROP INDEX IF EXISTS public.idx_orders_client_phone;
DROP INDEX IF EXISTS public.idx_orders_baggage;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_refresh_token_key;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.route_groups DROP CONSTRAINT IF EXISTS route_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.predefined_routes DROP CONSTRAINT IF EXISTS predefined_routes_pkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_order_id_key;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_sessions;
DROP TABLE IF EXISTS public.route_groups;
DROP TABLE IF EXISTS public.refresh_tokens;
DROP TABLE IF EXISTS public.predefined_routes;
DROP TABLE IF EXISTS public.payments;
DROP TABLE IF EXISTS public.orders;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pg_trgm;
--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: timetotravel_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO timetotravel_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: timetotravel_user
--

CREATE TABLE public.orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id character varying(255) NOT NULL,
    user_id uuid,
    from_lat numeric(10,7),
    from_lon numeric(10,7),
    to_lat numeric(10,7),
    to_lon numeric(10,7),
    from_address text NOT NULL,
    to_address text NOT NULL,
    distance_km numeric(10,2),
    raw_price numeric(10,2),
    final_price numeric(10,2) NOT NULL,
    base_cost numeric(10,2),
    cost_per_km numeric(10,2),
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    client_name character varying(255),
    client_phone character varying(20),
    departure_date date,
    departure_time time without time zone,
    passengers jsonb,
    baggage jsonb,
    pets jsonb,
    notes text,
    vehicle_class character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    trip_type character varying(50),
    direction character varying(50)
);


ALTER TABLE public.orders OWNER TO timetotravel_user;

--
-- Name: TABLE orders; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON TABLE public.orders IS 'Заказы такси / бронирования поездок';


--
-- Name: COLUMN orders.from_lat; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.from_lat IS 'Широта начальной точки (опционально - может быть null при создании)';


--
-- Name: COLUMN orders.from_lon; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.from_lon IS 'Долгота начальной точки (опционально - может быть null при создании)';


--
-- Name: COLUMN orders.to_lat; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.to_lat IS 'Широта конечной точки (опционально - может быть null при создании)';


--
-- Name: COLUMN orders.to_lon; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.to_lon IS 'Долгота конечной точки (опционально - может быть null при создании)';


--
-- Name: COLUMN orders.distance_km; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.distance_km IS 'Расстояние в км (опционально - вычисляется позже)';


--
-- Name: COLUMN orders.raw_price; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.raw_price IS 'Базовая цена без наценок (опционально - вычисляется позже)';


--
-- Name: COLUMN orders.base_cost; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.base_cost IS 'Базовая стоимость (опционально - вычисляется позже)';


--
-- Name: COLUMN orders.cost_per_km; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.cost_per_km IS 'Стоимость за км (опционально - вычисляется позже)';


--
-- Name: COLUMN orders.trip_type; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.trip_type IS 'Тип поездки: group (групповая), individual (индивидуальный трансфер), customRoute (свободный маршрут/такси)';


--
-- Name: COLUMN orders.direction; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON COLUMN public.orders.direction IS 'Направление: donetskToRostov или rostovToDonetsk (только для group и individual)';


--
-- Name: payments; Type: TABLE; Schema: public; Owner: timetotravel_user
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'RUB'::character varying,
    payment_method character varying(50),
    payment_provider character varying(50),
    transaction_id character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying,
    paid_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.payments OWNER TO timetotravel_user;

--
-- Name: TABLE payments; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON TABLE public.payments IS 'Платежи за заказы';


--
-- Name: predefined_routes; Type: TABLE; Schema: public; Owner: timetotravel_user
--

CREATE TABLE public.predefined_routes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    from_city character varying(255) NOT NULL,
    to_city character varying(255) NOT NULL,
    price numeric(10,2) NOT NULL,
    group_id uuid,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.predefined_routes OWNER TO timetotravel_user;

--
-- Name: TABLE predefined_routes; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON TABLE public.predefined_routes IS 'Предопределенные маршруты с ценами';


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: timetotravel_user
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.refresh_tokens OWNER TO timetotravel_user;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON TABLE public.refresh_tokens IS 'JWT Refresh токены для аутентификации';


--
-- Name: route_groups; Type: TABLE; Schema: public; Owner: timetotravel_user
--

CREATE TABLE public.route_groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.route_groups OWNER TO timetotravel_user;

--
-- Name: TABLE route_groups; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON TABLE public.route_groups IS 'Группы маршрутов для организации';


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: timetotravel_user
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    refresh_token text NOT NULL,
    device_info text,
    created_at timestamp without time zone DEFAULT now(),
    expires_at timestamp without time zone,
    last_used timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_sessions OWNER TO timetotravel_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: timetotravel_user
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(20),
    is_verified boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    role character varying(20) DEFAULT 'client'::character varying,
    telegram_id bigint,
    first_name character varying(100),
    last_name character varying(100),
    username character varying(100)
);


ALTER TABLE public.users OWNER TO timetotravel_user;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: timetotravel_user
--

COMMENT ON TABLE public.users IS 'Пользователи приложения';


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: timetotravel_user
--

COPY public.orders (id, order_id, user_id, from_lat, from_lon, to_lat, to_lon, from_address, to_address, distance_km, raw_price, final_price, base_cost, cost_per_km, status, client_name, client_phone, departure_date, departure_time, passengers, baggage, pets, notes, vehicle_class, created_at, updated_at, trip_type, direction) FROM stdin;
55d71cf5-a778-4c2f-8d03-0e05a8c35eec	ORDER-2026-01-001	\N	47.2357000	39.7015000	47.2361000	38.8975000	Ростов-на-Дону, пр. Ворошиловский, 48	Таганрог, ул. Петровская, 89	68.50	2300.00	2500.00	500.00	30.00	confirmed	Петров Иван Сергеевич	+79001112233	2026-01-25	14:30:00	[{"age": 35, "name": "Петров И.С."}]	[{"size": "medium", "type": "suitcase", "count": 1}]	\N	Встреча у главного входа	comfort	2026-01-22 09:33:10.893668+00	2026-01-22 20:22:07.677865+00	customRoute	\N
e501499a-0c14-4b44-a6c8-a6275e6d831a	ORDER-2026-01-002	\N	47.2585000	39.8181000	47.4936000	39.9247000	Ростов-на-Дону, ул. Большая Садовая, 115	Аэропорт Платов, Терминал А	42.30	1300.00	1500.00	400.00	26.00	pending	Сидорова Мария Петровна	+79002223344	2026-01-22	06:00:00	[{"age": 28, "name": "Сидорова М.П."}, {"age": 3, "name": "Сидорова Е.М."}]	[{"size": "large", "type": "suitcase", "count": 2}]	\N	Рейс в 08:30, нужно успеть на регистрацию	economy	2026-01-22 09:33:10.893668+00	2026-01-22 20:22:07.677865+00	customRoute	\N
63bda125-c745-49c3-bf36-c27b685fe64b	ORDER-2026-01-003	\N	47.2213000	39.7061000	47.1042000	39.4228000	Ростов-на-Дону, ул. Красноармейская, 170	Азов, ул. Московская, 56	35.80	1600.00	1800.00	400.00	40.00	completed	Иванов Алексей	+79003334455	2026-01-20	10:00:00	[{"age": 42, "name": "Иванов А."}]	[{"size": "small", "type": "bag", "count": 1}]	[{"name": "Бобик", "type": "dog", "weight": 12}]	Собака спокойная, в переноске	comfort	2026-01-22 09:33:10.893668+00	2026-01-22 20:22:07.677865+00	customRoute	\N
339cb424-4d01-4457-9f60-7f560c2a572d	ORDER-2026-01-832	\N	\N	\N	\N	\N	Донецк, ул. Артёма 120	Ростов-на-Дону	\N	\N	4000.00	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-22 17:59:59.835531+00	2026-01-22 20:22:07.677865+00	customRoute	\N
9a82770d-7f0d-4685-b5df-563be66d654a	ORDER-2026-01-346	\N	\N	\N	\N	\N	Донецк, ул. Артёма 120	Ростов-на-Дону	\N	\N	4000.00	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-22 18:05:46.354584+00	2026-01-22 20:22:07.677865+00	customRoute	\N
4b0b04e9-bc64-4e89-8b81-0ede545e0c83	ORDER-2026-01-797	\N	\N	\N	\N	\N	Донецк, ул. Артёма 120	Ростов-на-Дону	\N	\N	4000.00	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-22 18:08:59.808237+00	2026-01-22 20:22:07.677865+00	customRoute	\N
69bd5ab7-3678-4572-b35a-c0c1e72e4bb5	ORDER-2026-01-259	\N	\N	\N	\N	\N	Донецк	Ростов	\N	\N	3000.00	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-22 18:21:36.26178+00	2026-01-22 20:22:07.677865+00	customRoute	\N
ae0f29df-b8c0-4e76-8834-52fefe198518	ORDER-2026-01-788	\N	\N	\N	\N	\N	Донецк	Ростов	\N	\N	4000.00	\N	\N	pending	\N	\N	2026-01-25	20:31:00	\N	\N	\N	\N	\N	2026-01-22 18:53:21.804852+00	2026-01-22 20:22:07.677865+00	customRoute	\N
36f88315-8acf-4ff8-8e3e-f04a82671296	ORDER-2026-01-477	\N	\N	\N	\N	\N	Донецк	Ростов	\N	\N	4000.00	\N	\N	pending	\N	\N	2026-01-25	20:31:00	\N	\N	\N	\N	\N	2026-01-22 18:56:44.491681+00	2026-01-22 20:22:07.677865+00	customRoute	\N
34995b0b-e84c-44cc-be8a-e85ca5b88e16	ORDER-2026-01-745	\N	\N	\N	\N	\N	Не указан	Не указан	\N	\N	12000.00	\N	\N	pending	\N	\N	2026-01-27	06:00:00	\N	\N	\N	\N	\N	2026-01-22 20:06:24.762915+00	2026-01-22 20:22:07.677865+00	customRoute	\N
d246a57f-78e8-4f98-835d-de29f8f9cfe7	ORDER-2026-01-391	\N	\N	\N	\N	\N	Не указан	Не указан	\N	\N	11000.00	\N	\N	pending	\N	\N	2026-01-28	13:00:00	\N	\N	\N	\N	\N	2026-01-22 20:40:08.40403+00	2026-01-22 20:40:08.40403+00	group	donetskToRostov
ee3198be-3a6d-4c35-8cc4-6222f0b351ab	ORDER-2026-01-79	\N	\N	\N	\N	\N	Донецк, ул. Артема 1	Ростов-на-Дону, пр. Космонавтов 1	\N	\N	9500.00	\N	\N	pending	\N	\N	2026-01-29	14:00:00	[{"age": null, "name": null, "type": "adult", "seatType": null, "ageMonths": null, "useOwnSeat": null}, {"age": null, "name": null, "type": "adult", "seatType": null, "ageMonths": null, "useOwnSeat": null}, {"age": null, "name": null, "type": "child", "seatType": "booster", "ageMonths": 60, "useOwnSeat": null}]	[{"size": "s", "type": null, "count": null, "quantity": 2, "customDescription": null, "pricePerExtraItem": 500.0}, {"size": "l", "type": null, "count": null, "quantity": 1, "customDescription": null, "pricePerExtraItem": 2000.0}]	[{"cost": 0.0, "name": null, "type": null, "breed": "Кот Пушок", "weight": null, "category": "upTo5kgWithCarrier", "description": null}]	\N	\N	2026-01-22 20:47:21.095031+00	2026-01-22 20:47:21.095031+00	group	donetskToRostov
c3f10032-14a8-471a-984d-77ce1e63e8db	ORDER-2026-01-666	\N	\N	\N	\N	\N	улица Ленина, 6Б, село Кутейниково, Чертковский район, Ростовская область	улица Ленина, 24, Амвросиевка	\N	\N	14000.00	\N	\N	pending	\N	\N	2026-01-29	11:52:00	[{"age": null, "name": null, "type": "adult", "seatType": null, "ageMonths": null, "useOwnSeat": null}, {"age": null, "name": null, "type": "adult", "seatType": null, "ageMonths": null, "useOwnSeat": null}, {"age": null, "name": null, "type": "adult", "seatType": null, "ageMonths": null, "useOwnSeat": null}, {"age": null, "name": null, "type": "child", "seatType": null, "ageMonths": null, "useOwnSeat": null}]	[{"size": "s", "type": null, "count": null, "quantity": 1, "customDescription": null, "pricePerExtraItem": 500.0}, {"size": "m", "type": null, "count": null, "quantity": 3, "customDescription": null, "pricePerExtraItem": 1000.0}, {"size": "l", "type": null, "count": null, "quantity": 2, "customDescription": null, "pricePerExtraItem": 2000.0}]	[{"cost": 2000.0, "name": null, "type": null, "breed": "Животное свыше 6 кг", "weight": null, "category": "over6kg", "description": null}]	Текст есть ?	\N	2026-01-22 20:52:37.671326+00	2026-01-22 20:52:37.671326+00	individual	donetskToRostov
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: timetotravel_user
--

COPY public.payments (id, order_id, amount, currency, payment_method, payment_provider, transaction_id, status, paid_at, created_at) FROM stdin;
dc99a4a2-9804-4084-9512-b0afcb9a5bb1	55d71cf5-a778-4c2f-8d03-0e05a8c35eec	2500.00	RUB	cash	\N	\N	pending	\N	2026-01-22 09:33:10.89708+00
0baeed5d-c934-4e5d-a119-1f29274fa515	e501499a-0c14-4b44-a6c8-a6275e6d831a	1500.00	RUB	\N	\N	\N	pending	\N	2026-01-22 09:33:10.89708+00
a51bb265-5ac0-4bea-9a48-6f6cd0afb375	63bda125-c745-49c3-bf36-c27b685fe64b	1800.00	RUB	card	\N	\N	completed	2026-01-22 09:33:10.893668+00	2026-01-22 09:33:10.89708+00
\.


--
-- Data for Name: predefined_routes; Type: TABLE DATA; Schema: public; Owner: timetotravel_user
--

COPY public.predefined_routes (id, from_city, to_city, price, group_id, is_active, created_at, updated_at) FROM stdin;
895e9647-8f6d-401e-ad31-9bf758d00142	Ростов-на-Дону	Таганрог	2500.00	00000000-0000-0000-0000-000000000001	t	2026-01-22 09:33:10.888359+00	2026-01-22 09:33:10.888359+00
f0d05729-150b-4abc-8525-0876983baf1c	Ростов-на-Дону	Азов	1800.00	00000000-0000-0000-0000-000000000001	t	2026-01-22 09:33:10.888359+00	2026-01-22 09:33:10.888359+00
31d84eb5-6932-4662-a5ec-2d8a2a894136	Ростов-на-Дону	Батайск	800.00	00000000-0000-0000-0000-000000000001	t	2026-01-22 09:33:10.888359+00	2026-01-22 09:33:10.888359+00
bdf1057b-5a81-4cbe-98d7-d42f72dffba0	Таганрог	Ростов-на-Дону	2500.00	00000000-0000-0000-0000-000000000001	t	2026-01-22 09:33:10.888359+00	2026-01-22 09:33:10.888359+00
cc4c17e8-bd89-4062-9252-8283db75065b	Таганрог	Азов	1200.00	00000000-0000-0000-0000-000000000001	t	2026-01-22 09:33:10.888359+00	2026-01-22 09:33:10.888359+00
df8d77c0-98a6-44c6-895e-d38e3746c7cb	Ростов-на-Дону (центр)	Аэропорт Платов	1500.00	00000000-0000-0000-0000-000000000003	t	2026-01-22 09:33:10.888359+00	2026-01-22 09:33:10.888359+00
bb757e34-c9f5-49df-beb7-5e521c70c50e	Аэропорт Платов	Ростов-на-Дону (центр)	1500.00	00000000-0000-0000-0000-000000000003	t	2026-01-22 09:33:10.888359+00	2026-01-22 09:33:10.888359+00
a6ecad51-cc30-4850-b399-4ea9fbaa0bf5	Таганрог	Аэропорт Платов	3000.00	00000000-0000-0000-0000-000000000003	t	2026-01-22 09:33:10.888359+00	2026-01-22 09:33:10.888359+00
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: timetotravel_user
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, created_at) FROM stdin;
de7bd419-78ec-45cb-9031-1088df66f850	cfd5f42f-4cf6-4e84-a380-9dd6cf5793c6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjZmQ1ZjQyZi00Y2Y2LTRlODQtYTM4MC05ZGQ2Y2Y1NzkzYzYiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2OTA5NzQ1MSwiZXhwIjoxNzY5NzAyMjUxLCJpc3MiOiJ0aXRvdHIucnUifQ.CIaYxZQUiqQODzrymJ64ah_nR3fihcQEQxHmsPLX368	2026-01-29 15:57:31.998564+00	2026-01-22 15:57:31.999701+00
9e1f72df-8e50-492e-b049-10637f39ef3d	cfd5f42f-4cf6-4e84-a380-9dd6cf5793c6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjZmQ1ZjQyZi00Y2Y2LTRlODQtYTM4MC05ZGQ2Y2Y1NzkzYzYiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2OTA5NzQ2NSwiZXhwIjoxNzY5NzAyMjY1LCJpc3MiOiJ0aXRvdHIucnUifQ.iEcd8decf5hu4w-HqjJxcysN8_OrM7NU-kw4unJ4ouA	2026-01-29 15:57:45.741165+00	2026-01-22 15:57:45.74222+00
\.


--
-- Data for Name: route_groups; Type: TABLE DATA; Schema: public; Owner: timetotravel_user
--

COPY public.route_groups (id, name, description, is_active, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	Междугородние маршруты	Маршруты между городами Ростовской области	t	2026-01-22 09:33:10.88544+00	2026-01-22 09:33:10.88544+00
00000000-0000-0000-0000-000000000002	Местные поездки	Поездки внутри города	t	2026-01-22 09:33:10.88544+00	2026-01-22 09:33:10.88544+00
00000000-0000-0000-0000-000000000003	Аэропорт	Трансферы в/из аэропорта	t	2026-01-22 09:33:10.88544+00	2026-01-22 09:33:10.88544+00
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: timetotravel_user
--

COPY public.user_sessions (id, user_id, refresh_token, device_info, created_at, expires_at, last_used) FROM stdin;
649d0e41-cd13-4405-bf06-f8368f34cdc2	3b313f3f-25af-4bf2-a98a-2a24a7ba7ae6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzYjMxM2YzZi0yNWFmLTRiZjItYTk4YS0yYTI0YTdiYTdhZTYiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2OTE2MzMwMiwiZXhwIjoxNzY5NzY4MTAyLCJpc3MiOiJ0aXRvdHIucnUifQ.Q5o9pAEFwcM31MLoIZVCH25c0aqs67gyVupuW4t5Udg	\N	2026-01-23 10:15:02.90035	2026-01-30 10:15:02.89448	2026-01-23 10:15:02.90035
5eea40cd-60d3-437d-9cf4-00a4211aaccc	3b313f3f-25af-4bf2-a98a-2a24a7ba7ae6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzYjMxM2YzZi0yNWFmLTRiZjItYTk4YS0yYTI0YTdiYTdhZTYiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2OTE2MzQ5MywiZXhwIjoxNzY5NzY4MjkzLCJpc3MiOiJ0aXRvdHIucnUifQ.k9RE4klBWuFf-1BAdY6u1YaB1g4UNXlIsfj7eV17qX4	\N	2026-01-23 10:18:13.959981	2026-01-30 10:18:13.958745	2026-01-23 10:18:13.959981
ec840bf6-7762-4f2d-a546-625c796bd03b	3b313f3f-25af-4bf2-a98a-2a24a7ba7ae6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzYjMxM2YzZi0yNWFmLTRiZjItYTk4YS0yYTI0YTdiYTdhZTYiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2OTE2Mzk0MiwiZXhwIjoxNzY5NzY4NzQyLCJpc3MiOiJ0aXRvdHIucnUifQ.n2CKJJXqk6zfM9gNYnIXWMNcaRPRzd36l6LnD5lIwQw	\N	2026-01-23 10:25:42.004512	2026-01-30 10:25:42.003479	2026-01-23 10:25:42.004512
9a0ad77c-c89a-4322-893e-72691f9c14d4	3b313f3f-25af-4bf2-a98a-2a24a7ba7ae6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzYjMxM2YzZi0yNWFmLTRiZjItYTk4YS0yYTI0YTdiYTdhZTYiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2OTE2Mzk1MSwiZXhwIjoxNzY5NzY4NzUxLCJpc3MiOiJ0aXRvdHIucnUifQ.n4tqunaFMzOkRIJVZ61RSLIWHafe6waSpklWFpm6ezY	\N	2026-01-23 10:25:51.629707	2026-01-30 10:25:51.628539	2026-01-23 10:25:51.629707
de391c31-adf0-41fb-8513-ebed4aea7ae6	3b313f3f-25af-4bf2-a98a-2a24a7ba7ae6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzYjMxM2YzZi0yNWFmLTRiZjItYTk4YS0yYTI0YTdiYTdhZTYiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2OTE2NDE4OSwiZXhwIjoxNzY5NzY4OTg5LCJpc3MiOiJ0aXRvdHIucnUifQ._feSIo9KjHXPt-vCwklIVP2I4SdWgkJbd_KSdComSqw	\N	2026-01-23 10:29:49.301476	2026-01-30 10:29:49.300378	2026-01-23 10:29:49.301476
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: timetotravel_user
--

COPY public.users (id, email, password_hash, name, phone, is_verified, is_active, created_at, updated_at, role, telegram_id, first_name, last_name, username) FROM stdin;
0a95bc26-0d0d-4b16-8b31-31747993f1d5	test@titotr.ru	$2a$10$wnlhklnmT7pNjnIIWPSq3OCpu444bRy9WxjG3Mitgn0NTU05n/E1O	Test User	+79001234567	f	t	2026-01-22 10:37:45.338922+00	2026-01-22 10:37:45.338922+00	client	\N	\N	\N	\N
ec8648c9-a0c3-4967-8ab3-d75603712bc1	client@example.com	$2a$10$0w7VRSHuJ8xrFx.zpezLquY1pRPXLVqZy1Js89u8.cfl5eJGJRBkW	Тестовый Клиент	+79009998877	t	t	2026-01-22 09:33:10.891644+00	2026-01-22 10:40:39.072852+00	client	\N	\N	\N	\N
fb7a1315-f5fb-4eca-a710-1d44fa4c7f5b	admin@titotr.ru	$2a$10$0w7VRSHuJ8xrFx.zpezLquY1pRPXLVqZy1Js89u8.cfl5eJGJRBkW	Администратор	+79001234567	t	t	2026-01-22 09:33:10.891644+00	2026-01-22 10:40:39.072852+00	admin	\N	\N	\N	\N
44f81f77-4fdc-4e1d-918e-2a1e70d15b0a	driver@titotr.ru	$2a$10$0w7VRSHuJ8xrFx.zpezLquY1pRPXLVqZy1Js89u8.cfl5eJGJRBkW	Водитель Иван	+79007654321	t	t	2026-01-22 09:33:10.891644+00	2026-01-22 10:40:39.072852+00	driver	\N	\N	\N	\N
cfd5f42f-4cf6-4e84-a380-9dd6cf5793c6	test@example.com	$2a$10$p197RndGBYqUcBoJD7GjB.ZTKlWzLjWcLDkD90E0qUgDbKqv9L4Km	Test User	\N	f	t	2026-01-22 15:57:31.95538+00	2026-01-22 15:57:31.95538+00	client	\N	\N	\N	\N
94f77a1f-627f-4de1-8678-a1b87c2344e0	dispatcher@local		Dispatcher	+79895342496	f	t	2026-01-22 21:50:50.169258+00	2026-01-22 21:52:46.986873+00	dispatcher	999999999	Евгений	\N	nepeBo34uk
3b313f3f-25af-4bf2-a98a-2a24a7ba7ae6			Новый пользователь	+79504455444	f	t	2026-01-22 23:14:08.260196+00	2026-01-23 10:29:49.054174+00	passenger	771272324	Кирилл	Петров	osagowork
\.


--
-- Name: orders orders_order_id_key; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_id_key UNIQUE (order_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: predefined_routes predefined_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.predefined_routes
    ADD CONSTRAINT predefined_routes_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: route_groups route_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.route_groups
    ADD CONSTRAINT route_groups_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_refresh_token_key; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_refresh_token_key UNIQUE (refresh_token);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_orders_baggage; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_baggage ON public.orders USING gin (baggage);


--
-- Name: idx_orders_client_phone; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_client_phone ON public.orders USING btree (client_phone);


--
-- Name: idx_orders_created_at; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_created_at ON public.orders USING btree (created_at);


--
-- Name: idx_orders_departure_date; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_departure_date ON public.orders USING btree (departure_date);


--
-- Name: idx_orders_direction; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_direction ON public.orders USING btree (direction);


--
-- Name: idx_orders_order_id; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_order_id ON public.orders USING btree (order_id);


--
-- Name: idx_orders_passengers; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_passengers ON public.orders USING gin (passengers);


--
-- Name: idx_orders_pets; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_pets ON public.orders USING gin (pets);


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- Name: idx_orders_trip_type; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_trip_type ON public.orders USING btree (trip_type);


--
-- Name: idx_orders_user_id; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_orders_user_id ON public.orders USING btree (user_id);


--
-- Name: idx_payments_order_id; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_payments_order_id ON public.payments USING btree (order_id);


--
-- Name: idx_payments_status; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_payments_status ON public.payments USING btree (status);


--
-- Name: idx_payments_transaction_id; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_payments_transaction_id ON public.payments USING btree (transaction_id);


--
-- Name: idx_predefined_routes_cities; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_predefined_routes_cities ON public.predefined_routes USING btree (from_city, to_city);


--
-- Name: idx_predefined_routes_group_id; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_predefined_routes_group_id ON public.predefined_routes USING btree (group_id);


--
-- Name: idx_predefined_routes_is_active; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_predefined_routes_is_active ON public.predefined_routes USING btree (is_active);


--
-- Name: idx_refresh_tokens_expires_at; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_refresh_tokens_expires_at ON public.refresh_tokens USING btree (expires_at);


--
-- Name: idx_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: idx_route_groups_is_active; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_route_groups_is_active ON public.route_groups USING btree (is_active);


--
-- Name: idx_sessions_token; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_sessions_token ON public.user_sessions USING btree (refresh_token);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_sessions_user ON public.user_sessions USING btree (user_id);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_phone; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_users_phone ON public.users USING btree (phone);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_telegram_unique; Type: INDEX; Schema: public; Owner: timetotravel_user
--

CREATE UNIQUE INDEX idx_users_telegram_unique ON public.users USING btree (telegram_id) WHERE (telegram_id IS NOT NULL);


--
-- Name: orders update_orders_updated_at; Type: TRIGGER; Schema: public; Owner: timetotravel_user
--

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: predefined_routes update_predefined_routes_updated_at; Type: TRIGGER; Schema: public; Owner: timetotravel_user
--

CREATE TRIGGER update_predefined_routes_updated_at BEFORE UPDATE ON public.predefined_routes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: route_groups update_route_groups_updated_at; Type: TRIGGER; Schema: public; Owner: timetotravel_user
--

CREATE TRIGGER update_route_groups_updated_at BEFORE UPDATE ON public.route_groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: timetotravel_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: predefined_routes predefined_routes_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.predefined_routes
    ADD CONSTRAINT predefined_routes_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.route_groups(id) ON DELETE SET NULL;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: timetotravel_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: TABLE orders; Type: ACL; Schema: public; Owner: timetotravel_user
--

GRANT ALL ON TABLE public.orders TO timetotravel;


--
-- Name: TABLE payments; Type: ACL; Schema: public; Owner: timetotravel_user
--

GRANT ALL ON TABLE public.payments TO timetotravel;


--
-- Name: TABLE predefined_routes; Type: ACL; Schema: public; Owner: timetotravel_user
--

GRANT ALL ON TABLE public.predefined_routes TO timetotravel;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: public; Owner: timetotravel_user
--

GRANT ALL ON TABLE public.refresh_tokens TO timetotravel;


--
-- Name: TABLE route_groups; Type: ACL; Schema: public; Owner: timetotravel_user
--

GRANT ALL ON TABLE public.route_groups TO timetotravel;


--
-- Name: TABLE user_sessions; Type: ACL; Schema: public; Owner: timetotravel_user
--

GRANT ALL ON TABLE public.user_sessions TO timetotravel;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: timetotravel_user
--

GRANT ALL ON TABLE public.users TO timetotravel;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: timetotravel_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE timetotravel_user IN SCHEMA public GRANT ALL ON SEQUENCES TO timetotravel;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: timetotravel_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE timetotravel_user IN SCHEMA public GRANT ALL ON TABLES TO timetotravel;


--
-- PostgreSQL database dump complete
--

\unrestrict hPIkhLY3vWMLLAfyhWLF8FEK2oZvTyEfxfWRhayw1uJ6UGubWAkvnnCOLgYkemc

