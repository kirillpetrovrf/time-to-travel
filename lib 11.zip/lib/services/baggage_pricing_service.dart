import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/baggage.dart';

/// Сервис для управления ценами на дополнительный багаж (ТЗ v3.0)
/// ОБНОВЛЕНО: Цены загружаются из Firebase и управляются диспетчером
class BaggagePricingService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static const String _collectionPath = 'settings';
  static const String _documentId = 'baggage_pricing';

  // Дефолтные цены (если Firebase недоступен)
  static const double defaultSPricePerExtra = 500.0; // S: 500₽
  static const double defaultMPricePerExtra = 1000.0; // M: 1000₽
  static const double defaultLPricePerExtra = 2000.0; // L: 2000₽
  static const double defaultCustomPricePerExtra =
      0.0; // Custom: цена определяется диспетчером

  // Текст для индивидуального багажа
  static const String customBaggagePriceText =
      'Для уточнения цены нужно связаться с диспетчером. '
      'После оформления заказа с Вами свяжется диспетчер и скажет точную стоимость индивидуального багажа.';

  /// Получение цен на дополнительный багаж из Firebase
  static Future<Map<BaggageSize, double>> getExtraBaggagePrices() async {
    try {
      final doc = await _firestore
          .collection(_collectionPath)
          .doc(_documentId)
          .get();

      if (!doc.exists) {
        // Если документа нет, создаём с дефолтными ценами
        await _createDefaultPrices();
        return _getDefaultPrices();
      }

      final data = doc.data() as Map<String, dynamic>;

      return {
        BaggageSize.s: (data['extra_s_price'] ?? defaultSPricePerExtra)
            .toDouble(),
        BaggageSize.m: (data['extra_m_price'] ?? defaultMPricePerExtra)
            .toDouble(),
        BaggageSize.l: (data['extra_l_price'] ?? defaultLPricePerExtra)
            .toDouble(),
        BaggageSize.custom:
            (data['extra_custom_price'] ?? defaultCustomPricePerExtra)
                .toDouble(),
      };
    } catch (e) {
      print('❌ Ошибка загрузки цен багажа из Firebase: $e');
      return _getDefaultPrices();
    }
  }

  /// Обновление цен на дополнительный багаж (для диспетчера)
  static Future<void> updateExtraBaggagePrices({
    required double sPricePerExtra,
    required double mPricePerExtra,
    required double lPricePerExtra,
    required double customPricePerExtra,
  }) async {
    try {
      await _firestore.collection(_collectionPath).doc(_documentId).set({
        'extra_s_price': sPricePerExtra,
        'extra_m_price': mPricePerExtra,
        'extra_l_price': lPricePerExtra,
        'extra_custom_price': customPricePerExtra,
        'updated_at': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      print('✅ Цены багажа успешно обновлены');
    } catch (e) {
      print('❌ Ошибка обновления цен багажа: $e');
      throw Exception('Не удалось обновить цены багажа');
    }
  }

  /// Стрим для отслеживания изменений цен в реальном времени
  static Stream<Map<BaggageSize, double>> getExtraBaggagePricesStream() {
    return _firestore
        .collection(_collectionPath)
        .doc(_documentId)
        .snapshots()
        .map((doc) {
          if (!doc.exists) {
            return _getDefaultPrices();
          }

          final data = doc.data() as Map<String, dynamic>;

          return {
            BaggageSize.s: (data['extra_s_price'] ?? defaultSPricePerExtra)
                .toDouble(),
            BaggageSize.m: (data['extra_m_price'] ?? defaultMPricePerExtra)
                .toDouble(),
            BaggageSize.l: (data['extra_l_price'] ?? defaultLPricePerExtra)
                .toDouble(),
            BaggageSize.custom:
                (data['extra_custom_price'] ?? defaultCustomPricePerExtra)
                    .toDouble(),
          };
        });
  }

  /// Создание дефолтных цен в Firebase
  static Future<void> _createDefaultPrices() async {
    try {
      await _firestore.collection(_collectionPath).doc(_documentId).set({
        'extra_s_price': defaultSPricePerExtra,
        'extra_m_price': defaultMPricePerExtra,
        'extra_l_price': defaultLPricePerExtra,
        'extra_custom_price': defaultCustomPricePerExtra,
        'created_at': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('❌ Ошибка создания дефолтных цен: $e');
    }
  }

  /// Получение дефолтных цен
  static Map<BaggageSize, double> _getDefaultPrices() {
    return {
      BaggageSize.s: defaultSPricePerExtra,
      BaggageSize.m: defaultMPricePerExtra,
      BaggageSize.l: defaultLPricePerExtra,
      BaggageSize.custom: defaultCustomPricePerExtra,
    };
  }

  /// Создание BaggageItem с актуальными ценами
  static Future<BaggageItem> createBaggageItemWithPricing({
    required BaggageSize size,
    required int quantity,
    String? customDescription,
    String? customDimensions,
  }) async {
    final prices = await getExtraBaggagePrices();
    final pricePerExtraItem = prices[size] ?? 0.0;

    return BaggageItem(
      size: size,
      quantity: quantity,
      customDescription: customDescription,
      customDimensions: customDimensions,
      pricePerExtraItem: pricePerExtraItem,
    );
  }

  /// Получение информации о стоимости для отображения в UI
  static Future<String> getPriceDisplayText(BaggageSize size) async {
    final prices = await getExtraBaggagePrices();
    final pricePerExtra = prices[size] ?? 0.0;

    if (size == BaggageSize.custom) {
      return 'Цена уточняется диспетчером';
    } else if (pricePerExtra == 0.0) {
      return 'БЕСПЛАТНО';
    } else {
      return 'Доп. багаж: ${pricePerExtra.toStringAsFixed(0)}₽/шт';
    }
  }
}
