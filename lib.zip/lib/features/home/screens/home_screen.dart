import 'package:flutter/cupertino.dart';
import '../../../services/auth_service.dart';
import '../../rides/screens/create_ride_screen.dart';
import '../../rides/screens/search_rides_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _restoreLastTab();
  }

  void _restoreLastTab() async {
    final authService = AuthService.instance;
    final lastScreen = await authService.getLastScreen();

    if (lastScreen != null) {
      int tabIndex = 0;
      switch (lastScreen) {
        case '/home':
          tabIndex = 0;
          break;
        case '/search-rides':
          tabIndex = 1;
          break;
        case '/create-ride':
          tabIndex = 2;
          break;
        case '/chats':
          tabIndex = 3;
          break;
        case '/profile':
          tabIndex = 4;
          break;
      }

      if (mounted) {
        setState(() {
          _currentIndex = tabIndex;
        });
      }
    }
  }

  void _onTabChanged(int index) async {
    setState(() {
      _currentIndex = index;
    });

    // Сохраняем текущую вкладку
    final authService = AuthService.instance;
    String route = '/home';
    switch (index) {
      case 0:
        route = '/home';
        break;
      case 1:
        route = '/search-rides';
        break;
      case 2:
        route = '/create-ride';
        break;
      case 3:
        route = '/chats';
        break;
      case 4:
        route = '/profile';
        break;
    }
    await authService.saveLastScreen(route);
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoTabScaffold(
      tabBar: CupertinoTabBar(
        activeColor: CupertinoColors.systemBlue,
        currentIndex: _currentIndex,
        onTap: _onTabChanged,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(CupertinoIcons.home),
            label: 'Главная',
          ),
          BottomNavigationBarItem(
            icon: Icon(CupertinoIcons.search),
            label: 'Поиск',
          ),
          BottomNavigationBarItem(
            icon: Icon(CupertinoIcons.add_circled),
            label: 'Создать',
          ),
          BottomNavigationBarItem(
            icon: Icon(CupertinoIcons.chat_bubble_2),
            label: 'Чаты',
          ),
          BottomNavigationBarItem(
            icon: Icon(CupertinoIcons.person),
            label: 'Профиль',
          ),
        ],
      ),
      tabBuilder: (context, index) {
        switch (index) {
          case 0:
            return const MainTab();
          case 1:
            return const SearchTab();
          case 2:
            return const CreateRideTab();
          case 3:
            return const ChatsTab();
          case 4:
            return const ProfileTab();
          default:
            return const MainTab();
        }
      },
    );
  }
}

// Главная вкладка
class MainTab extends StatefulWidget {
  const MainTab({super.key});

  @override
  State<MainTab> createState() => _MainTabState();
}

class _MainTabState extends State<MainTab> {
  String? _userName;

  @override
  void initState() {
    super.initState();
    _loadUserData();
    // Убираем автоматическое сохранение экрана при загрузке
  }

  void _loadUserData() async {
    final authService = AuthService.instance;
    final userData = await authService.getFormData('user_profile');

    if (userData != null) {
      setState(() {
        _userName = userData['userName'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: const CupertinoNavigationBar(middle: Text('Главная')),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Приветствие
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: CupertinoColors.systemBlue,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Привет, ${_userName ?? 'Пользователь'}!',
                      style: const TextStyle(
                        color: CupertinoColors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Куда поедем сегодня?',
                      style: TextStyle(
                        color: CupertinoColors.white,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Быстрые действия
              const Text(
                'Быстрые действия',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: _QuickActionCard(
                      icon: CupertinoIcons.car,
                      title: 'Найти поездку',
                      subtitle: 'Найти попутчика',
                      color: CupertinoColors.systemGreen,
                      onTap: () {
                        // Переключаемся на вкладку поиска
                        final homeState = context
                            .findAncestorStateOfType<_HomeScreenState>();
                        homeState?._onTabChanged(1);
                      },
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _QuickActionCard(
                      icon: CupertinoIcons.add,
                      title: 'Создать поездку',
                      subtitle: 'Предложить место',
                      color: CupertinoColors.systemOrange,
                      onTap: () {
                        // Переключаемся на вкладку создания поездки
                        final homeState = context
                            .findAncestorStateOfType<_HomeScreenState>();
                        homeState?._onTabChanged(2);
                      },
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // Последние поездки
              const Text(
                'Последние поездки',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 16),

              Expanded(
                child: ListView.builder(
                  itemCount: 3,
                  itemBuilder: (context, index) {
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: CupertinoColors.systemGrey6,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 48,
                            height: 48,
                            decoration: const BoxDecoration(
                              color: CupertinoColors.systemBlue,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              CupertinoIcons.location,
                              color: CupertinoColors.white,
                            ),
                          ),
                          const SizedBox(width: 16),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Казань → Москва',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  '15 декабря, 09:00',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: CupertinoColors.secondaryLabel,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Text(
                            '1500 ₽',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: CupertinoColors.systemGreen,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _QuickActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, size: 32, color: color),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: const TextStyle(
                fontSize: 12,
                color: CupertinoColors.secondaryLabel,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// Остальные вкладки (заглушки)
class SearchTab extends StatelessWidget {
  const SearchTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const SearchRidesScreen();
  }
}

class CreateRideTab extends StatelessWidget {
  const CreateRideTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const CreateRideScreen();
  }
}

class ChatsTab extends StatelessWidget {
  const ChatsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(middle: Text('Чаты')),
      child: Center(child: Text('Чаты')),
    );
  }
}

class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  String? _userName;
  String? _phoneNumber;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  void _loadUserData() async {
    final authService = AuthService.instance;
    final userData = await authService.getFormData('user_profile');

    if (userData != null) {
      setState(() {
        _userName = userData['userName'];
        _phoneNumber = userData['phoneNumber'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: const CupertinoNavigationBar(middle: Text('Профиль')),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Информация о пользователе
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: CupertinoColors.systemGrey6,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 60,
                          height: 60,
                          decoration: const BoxDecoration(
                            color: CupertinoColors.systemBlue,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            CupertinoIcons.person,
                            color: CupertinoColors.white,
                            size: 30,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _userName ?? 'Загрузка...',
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _phoneNumber ?? 'Загрузка...',
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: CupertinoColors.secondaryLabel,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 32),

              // Действия
              _buildMenuItem(
                icon: CupertinoIcons.paintbrush,
                title: 'Настройки дизайна',
                onTap: () {
                  Navigator.pushNamed(context, '/theme-editor');
                },
              ),

              const SizedBox(height: 16),

              _buildMenuItem(
                icon: CupertinoIcons.settings,
                title: 'Настройки',
                onTap: () {
                  // TODO: Implement settings
                },
              ),

              const SizedBox(height: 16),

              _buildMenuItem(
                icon: CupertinoIcons.info_circle,
                title: 'О приложении',
                onTap: () {
                  // TODO: Implement about
                },
              ),

              const Spacer(),

              // Кнопка выхода
              SizedBox(
                width: double.infinity,
                child: CupertinoButton(
                  color: CupertinoColors.systemRed,
                  borderRadius: BorderRadius.circular(12),
                  onPressed: _handleLogout,
                  child: const Text(
                    'Выйти из аккаунта',
                    style: TextStyle(
                      color: CupertinoColors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: CupertinoColors.systemGrey6,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: CupertinoColors.systemBlue, size: 24),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const Icon(
              CupertinoIcons.chevron_right,
              color: CupertinoColors.secondaryLabel,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  void _handleLogout() async {
    // Показываем диалог подтверждения
    final shouldLogout = await showCupertinoDialog<bool>(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text('Выйти из аккаунта'),
        content: const Text('Вы уверены, что хотите выйти?'),
        actions: [
          CupertinoDialogAction(
            child: const Text('Отмена'),
            onPressed: () => Navigator.pop(context, false),
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            child: const Text('Выйти'),
            onPressed: () => Navigator.pop(context, true),
          ),
        ],
      ),
    );

    if (shouldLogout == true) {
      // Выходим из системы
      final authService = AuthService.instance;
      await authService.logout();

      if (mounted) {
        // Переходим на экран авторизации
        Navigator.pushNamedAndRemoveUntil(context, '/auth', (route) => false);
      }
    }
  }
}
