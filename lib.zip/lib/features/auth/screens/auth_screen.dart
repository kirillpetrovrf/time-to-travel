import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../../services/auth_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _phoneController = TextEditingController();
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    final keyboardHeight = MediaQuery.of(context).viewInsets.bottom;
    final isKeyboardVisible = keyboardHeight > 0;

    return CupertinoPageScaffold(
      navigationBar: const CupertinoNavigationBar(
        middle: Text('Такси Попутчик'),
        backgroundColor: CupertinoColors.systemBackground,
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.only(
            left: 16.0,
            right: 16.0,
            top: 16.0,
            bottom: keyboardHeight + 16.0,
          ),
          child: Container(
            width: double.infinity,
            constraints: BoxConstraints(
              minHeight:
                  MediaQuery.of(context).size.height -
                  MediaQuery.of(context).padding.top -
                  MediaQuery.of(context).padding.bottom -
                  kToolbarHeight,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Логотип приложения (адаптируем размер при клавиатуре)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: isKeyboardVisible ? 80 : 120,
                  height: isKeyboardVisible ? 80 : 120,
                  decoration: BoxDecoration(
                    color: CupertinoColors.systemBlue,
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Icon(
                    CupertinoIcons.car_detailed,
                    size: isKeyboardVisible ? 40 : 60,
                    color: CupertinoColors.white,
                  ),
                ),

                SizedBox(height: isKeyboardVisible ? 16 : 32),

                // Заголовок
                Text(
                  'Добро пожаловать!',
                  style: TextStyle(
                    fontSize: isKeyboardVisible ? 24 : 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                SizedBox(height: isKeyboardVisible ? 4 : 8),

                // Подзаголовок
                Text(
                  'Введите номер телефона для входа или регистрации',
                  style: TextStyle(
                    fontSize: isKeyboardVisible ? 14 : 16,
                    color: CupertinoColors.secondaryLabel,
                  ),
                  textAlign: TextAlign.center,
                ),

                SizedBox(height: isKeyboardVisible ? 16 : 32),

                // Поле ввода телефона
                CupertinoTextField(
                  controller: _phoneController,
                  placeholder: '+7 (999) 123-45-67',
                  keyboardType: TextInputType.phone,
                  prefix: const Padding(
                    padding: EdgeInsets.only(left: 12.0),
                    child: Icon(
                      CupertinoIcons.phone,
                      color: CupertinoColors.secondaryLabel,
                      size: 20,
                    ),
                  ),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: CupertinoColors.separator),
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),

                SizedBox(height: isKeyboardVisible ? 16 : 24),

                // Кнопка входа
                SizedBox(
                  width: double.infinity,
                  child: CupertinoButton(
                    color: CupertinoColors.systemBlue,
                    borderRadius: BorderRadius.circular(12),
                    onPressed: _isLoading ? null : _handleLogin,
                    child: _isLoading
                        ? const CupertinoActivityIndicator(
                            color: CupertinoColors.white,
                          )
                        : const Text(
                            'Получить код',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: CupertinoColors
                                  .white, // Явно указываем белый цвет
                            ),
                          ),
                  ),
                ),

                SizedBox(height: isKeyboardVisible ? 8 : 16),

                // Переход к редактору тем (скрываем при клавиатуре)
                if (!isKeyboardVisible) ...[
                  CupertinoButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/theme-editor');
                    },
                    child: const Text('Настройки дизайна'),
                  ),

                  const SizedBox(height: 32),
                ],

                // Соглашение (уменьшаем при клавиатуре)
                if (!isKeyboardVisible)
                  Text(
                    'Продолжая, вы соглашаетесь с условиями использования и политикой конфиденциальности',
                    style: TextStyle(
                      fontSize: isKeyboardVisible ? 10 : 12,
                      color: CupertinoColors.secondaryLabel,
                    ),
                    textAlign: TextAlign.center,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _handleLogin() async {
    if (_phoneController.text.isEmpty) {
      _showAlert('Ошибка', 'Введите номер телефона');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Имитация запроса к серверу
      await Future.delayed(const Duration(seconds: 2));

      // Сохраняем данные авторизации
      final authService = AuthService.instance;
      await authService.login(
        phoneNumber: _phoneController.text,
        userName: 'Пользователь', // В реальном приложении получим с сервера
      );

      // Сохраняем данные профиля для отображения в интерфейсе
      await authService.saveFormData('user_profile', {
        'userName': 'Пользователь',
        'phoneNumber': _phoneController.text,
      });

      // Сохраняем главный экран как начальный
      await authService.saveLastScreen('/home');

      setState(() {
        _isLoading = false;
      });

      // Переход к главному экрану
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/home');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showAlert('Ошибка', 'Произошла ошибка при авторизации: $e');
    }
  }

  void _showAlert(String title, String message) {
    showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          CupertinoDialogAction(
            child: const Text('OK'),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }
}
