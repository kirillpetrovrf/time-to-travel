abstract interface class DisposableDeps {
  void disposeAll();
}
