final class AlertStrings {
  static const dialogAcceptButtonText = "OK";
  static const dialogCancelButtonText = "Cancel";

  static const dialogYesButtonText = "Yes";
  static const dialogNoButtonText = "No";

  static const requestLocationPermissionDialogText =
      "Please, let us access your exact location.";
}
