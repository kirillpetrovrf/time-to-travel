final class SettingsStrings {
  static const fancyButton = "I'm a fancy button";
}
