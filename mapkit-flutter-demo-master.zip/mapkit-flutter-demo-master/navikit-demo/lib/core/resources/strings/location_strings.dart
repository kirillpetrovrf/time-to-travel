final class LocationStrings {
  static const location = "location:";
  static const latitude = "latitude";
  static const longitude = "longitude";
  static const heading = "heading";

  static const camera = "camera:";
  static const azimuth = "azimuth";
}
