final class GuidanceStrings {
  static const distance = "Distance:";
  static const time = "Time:";
  static const flags = "Flags:";
  static const street = "Street:";

  static const closeGuidanceDialogText = "Cancel route guidance?";
}
