final class LogsStrings {
  static const navigationWasSerializedLog = "Navigation was serialized";
  static const deserializedNavigationLog =
      "Deserialized Navigation successfully";
  static const failedToDeserializeNavigationLog =
      "Failed to deserialize Navigation";
}
