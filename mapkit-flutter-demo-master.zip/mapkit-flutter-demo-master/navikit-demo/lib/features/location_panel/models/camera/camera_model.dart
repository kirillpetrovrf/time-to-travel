final class CameraModel {
  final double? azimuth;

  const CameraModel({required this.azimuth});
}
