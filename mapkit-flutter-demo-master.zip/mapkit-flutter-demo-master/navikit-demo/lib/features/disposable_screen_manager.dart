abstract interface class DisposableScreenManager {
  void dispose();
}
