final class RouteVariantsScreenModel {
  final bool? isRouteVariantsVisible;

  const RouteVariantsScreenModel({required this.isRouteVariantsVisible});
}
