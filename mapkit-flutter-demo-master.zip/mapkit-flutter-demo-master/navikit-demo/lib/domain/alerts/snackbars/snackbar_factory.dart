abstract interface class SnackBarFactory {
  bool showSnackBar(String text);
}
