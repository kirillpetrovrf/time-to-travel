import 'package:yandex_maps_navikit/navigation.dart';

abstract interface class NavigationStyleManager
    extends NavigationStyleProvider {}
