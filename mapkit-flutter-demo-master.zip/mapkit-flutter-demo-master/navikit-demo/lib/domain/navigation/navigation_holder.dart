import 'package:yandex_maps_navikit/navigation.dart';

abstract interface class NavigationHolder {
  Navigation get navigation;

  void serialize();
}
