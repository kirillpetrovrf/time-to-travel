abstract interface class DisposableManager {
  void dispose();
}
