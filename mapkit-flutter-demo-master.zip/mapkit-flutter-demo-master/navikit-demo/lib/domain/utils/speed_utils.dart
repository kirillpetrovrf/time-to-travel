extension ToMetersPerSecond on double {
  double toMetersPerSecond() => this / 3.6;
}
