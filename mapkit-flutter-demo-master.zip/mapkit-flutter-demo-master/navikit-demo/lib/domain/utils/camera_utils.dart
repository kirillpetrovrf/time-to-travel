import 'package:yandex_maps_navikit/mapkit.dart';

class CameraAnimations {
  static const defaultAnimation =
      Animation(AnimationType.Smooth, duration: 0.6);
}
