package com.yandex.map_with_user_placemark

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
