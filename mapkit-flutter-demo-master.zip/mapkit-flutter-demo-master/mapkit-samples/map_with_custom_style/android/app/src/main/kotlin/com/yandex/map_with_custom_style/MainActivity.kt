package com.yandex.map_with_custom_style

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
