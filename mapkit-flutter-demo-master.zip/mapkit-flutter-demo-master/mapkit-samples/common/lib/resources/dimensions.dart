final class Dimensions {
  static const commonPadding = 10.0;
}
