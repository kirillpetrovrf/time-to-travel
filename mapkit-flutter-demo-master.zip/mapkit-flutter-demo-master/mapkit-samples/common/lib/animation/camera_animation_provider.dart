import 'package:yandex_maps_mapkit/mapkit.dart';

final class CameraAnimationProvider {
  static const defaultCameraAnimation = Animation(
    AnimationType.Smooth,
    duration: 0.5,
  );
}
