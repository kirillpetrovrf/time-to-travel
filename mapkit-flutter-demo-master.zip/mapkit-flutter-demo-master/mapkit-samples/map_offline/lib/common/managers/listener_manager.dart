abstract interface class ListenerManager {
  void startListening();
  void dispose();
}
