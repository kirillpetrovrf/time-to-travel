package com.yandex.map_offline

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
