package com.yandex.map_with_panorama

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
