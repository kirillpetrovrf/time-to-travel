enum TrafficState { ok, loading, expired }
