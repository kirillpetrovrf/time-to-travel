package com.yandex.map_with_jams

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
