package com.yandex.map_objects

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
