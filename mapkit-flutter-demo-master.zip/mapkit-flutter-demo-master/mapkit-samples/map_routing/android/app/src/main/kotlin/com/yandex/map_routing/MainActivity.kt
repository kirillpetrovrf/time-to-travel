package com.yandex.map_routing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
