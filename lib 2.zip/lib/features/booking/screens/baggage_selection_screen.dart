import 'package:flutter/cupertino.dart';
import '../../../models/baggage.dart';
import '../../../theme/theme_manager.dart';
import '../../../theme/app_theme.dart';

class BaggageSelectionScreen extends StatefulWidget {
  final List<BaggageItem> initialBaggage;
  final Function(List<BaggageItem>) onBaggageSelected;

  const BaggageSelectionScreen({
    super.key,
    this.initialBaggage = const [],
    required this.onBaggageSelected,
  });

  @override
  State<BaggageSelectionScreen> createState() => _BaggageSelectionScreenState();
}

class _BaggageSelectionScreenState extends State<BaggageSelectionScreen> {
  final List<BaggageItem> _baggageItems = [];
  final TextEditingController _customDescriptionController =
      TextEditingController();
  final TextEditingController _customDimensionsController =
      TextEditingController();

  @override
  void initState() {
    super.initState();
    _baggageItems.addAll(widget.initialBaggage);
  }

  @override
  void dispose() {
    _customDescriptionController.dispose();
    _customDimensionsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeManager = context.themeManager;
    final theme = themeManager.currentTheme;

    return CupertinoPageScaffold(
      backgroundColor: theme.systemBackground,
      navigationBar: CupertinoNavigationBar(
        backgroundColor: theme.secondarySystemBackground,
        middle: Text('Выбор багажа', style: TextStyle(color: theme.label)),
        leading: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: () => Navigator.of(context).pop(),
          child: Icon(CupertinoIcons.back, color: theme.primary),
        ),
        trailing: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: _saveBaggage,
          child: Text(
            'Готово',
            style: TextStyle(color: theme.primary, fontWeight: FontWeight.w600),
          ),
        ),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Заголовок
            Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    'Добавьте информацию о багаже',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: theme.label,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Укажите размеры и количество вашего багажа',
                    style: TextStyle(fontSize: 16, color: theme.secondaryLabel),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),

            // Стандартные размеры
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Стандартные размеры',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: theme.label,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Рюкзак (S)
                    _BaggageSizeCard(
                      size: BaggageSize.small,
                      theme: theme,
                      quantity: _getQuantityForSize(BaggageSize.small),
                      onQuantityChanged: (quantity) {
                        _updateBaggageQuantity(BaggageSize.small, quantity);
                      },
                    ),

                    const SizedBox(height: 12),

                    // Спортивная сумка (M)
                    _BaggageSizeCard(
                      size: BaggageSize.medium,
                      theme: theme,
                      quantity: _getQuantityForSize(BaggageSize.medium),
                      onQuantityChanged: (quantity) {
                        _updateBaggageQuantity(BaggageSize.medium, quantity);
                      },
                    ),

                    const SizedBox(height: 12),

                    // Чемодан (L)
                    _BaggageSizeCard(
                      size: BaggageSize.large,
                      theme: theme,
                      quantity: _getQuantityForSize(BaggageSize.large),
                      onQuantityChanged: (quantity) {
                        _updateBaggageQuantity(BaggageSize.large, quantity);
                      },
                    ),

                    const SizedBox(height: 24),

                    // Пользовательский размер
                    Text(
                      'Другой размер',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: theme.label,
                      ),
                    ),
                    const SizedBox(height: 16),

                    _CustomBaggageCard(
                      theme: theme,
                      descriptionController: _customDescriptionController,
                      dimensionsController: _customDimensionsController,
                      onAddCustom: _addCustomBaggage,
                    ),

                    const SizedBox(height: 24),

                    // Список добавленного багажа
                    if (_baggageItems.isNotEmpty) ...[
                      Text(
                        'Добавленный багаж',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: theme.label,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ..._baggageItems.asMap().entries.map((entry) {
                        final index = entry.key;
                        final item = entry.value;
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: _BaggageItemCard(
                            item: item,
                            theme: theme,
                            onRemove: () => _removeBaggageItem(index),
                          ),
                        );
                      }).toList(),
                      const SizedBox(height: 24),
                    ],

                    // Информация о перевозке
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: theme.secondarySystemBackground,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                CupertinoIcons.info_circle_fill,
                                color: CupertinoColors.systemBlue,
                                size: 20,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'Важная информация',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: theme.label,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            '• Багаж перевозится в багажном отделении\n'
                            '• Хрупкие вещи сообщите водителю заранее\n'
                            '• За крупный багаж может взиматься доплата\n'
                            '• Максимальный вес одного места: 30 кг',
                            style: TextStyle(
                              fontSize: 14,
                              color: theme.secondaryLabel,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  int _getQuantityForSize(BaggageSize size) {
    return _baggageItems
        .where((item) => item.size == size)
        .fold(0, (sum, item) => sum + item.quantity);
  }

  void _updateBaggageQuantity(BaggageSize size, int quantity) {
    setState(() {
      // Удаляем все существующие элементы этого размера
      _baggageItems.removeWhere((item) => item.size == size);

      // Добавляем новый элемент с нужным количеством, если quantity > 0
      if (quantity > 0) {
        _baggageItems.add(BaggageItem(size: size, quantity: quantity));
      }
    });
  }

  void _addCustomBaggage() {
    if (_customDescriptionController.text.trim().isEmpty ||
        _customDimensionsController.text.trim().isEmpty) {
      _showAlert('Заполните все поля для пользовательского багажа');
      return;
    }

    setState(() {
      _baggageItems.add(
        BaggageItem(
          size: BaggageSize.custom,
          quantity: 1,
          customDescription: _customDescriptionController.text.trim(),
          customDimensions: _customDimensionsController.text.trim(),
        ),
      );
    });

    _customDescriptionController.clear();
    _customDimensionsController.clear();
  }

  void _removeBaggageItem(int index) {
    setState(() {
      _baggageItems.removeAt(index);
    });
  }

  void _saveBaggage() {
    widget.onBaggageSelected(_baggageItems);
    Navigator.of(context).pop();
  }

  void _showAlert(String message) {
    showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text('Внимание'),
        content: Text(message),
        actions: [
          CupertinoDialogAction(
            child: const Text('OK'),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }
}

class _BaggageSizeCard extends StatelessWidget {
  final BaggageSize size;
  final CustomTheme theme;
  final int quantity;
  final Function(int) onQuantityChanged;

  const _BaggageSizeCard({
    required this.size,
    required this.theme,
    required this.quantity,
    required this.onQuantityChanged,
  });

  @override
  Widget build(BuildContext context) {
    final item = BaggageItem(size: size, quantity: 1);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.secondarySystemBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: quantity > 0 ? theme.primary : theme.separator,
          width: quantity > 0 ? 2 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.sizeDescription,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: theme.label,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item.dimensions,
                      style: TextStyle(
                        fontSize: 14,
                        color: theme.secondaryLabel,
                      ),
                    ),
                  ],
                ),
              ),
              _QuantityPicker(
                quantity: quantity,
                theme: theme,
                onChanged: onQuantityChanged,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CustomBaggageCard extends StatelessWidget {
  final CustomTheme theme;
  final TextEditingController descriptionController;
  final TextEditingController dimensionsController;
  final VoidCallback onAddCustom;

  const _CustomBaggageCard({
    required this.theme,
    required this.descriptionController,
    required this.dimensionsController,
    required this.onAddCustom,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.secondarySystemBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.separator),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Описание',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: theme.label,
            ),
          ),
          const SizedBox(height: 8),
          CupertinoTextField(
            controller: descriptionController,
            placeholder: 'Например: Коробка с хрупкими вещами',
            style: TextStyle(color: theme.label),
            decoration: BoxDecoration(
              color: theme.systemBackground,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: theme.separator),
            ),
            placeholderStyle: TextStyle(color: theme.placeholderText),
          ),

          const SizedBox(height: 16),

          Text(
            'Размеры (Д×Ш×В см)',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: theme.label,
            ),
          ),
          const SizedBox(height: 8),
          CupertinoTextField(
            controller: dimensionsController,
            placeholder: 'Например: 60×40×30',
            style: TextStyle(color: theme.label),
            decoration: BoxDecoration(
              color: theme.systemBackground,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: theme.separator),
            ),
            placeholderStyle: TextStyle(color: theme.placeholderText),
          ),

          const SizedBox(height: 16),

          CupertinoButton(
            color: theme.primary,
            onPressed: onAddCustom,
            child: const Text(
              'Добавить',
              style: TextStyle(
                color: CupertinoColors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BaggageItemCard extends StatelessWidget {
  final BaggageItem item;
  final CustomTheme theme;
  final VoidCallback onRemove;

  const _BaggageItemCard({
    required this.item,
    required this.theme,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.secondarySystemBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.separator),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.sizeDescription,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: theme.label,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Размеры: ${item.dimensions}',
                  style: TextStyle(fontSize: 14, color: theme.secondaryLabel),
                ),
                Text(
                  'Количество: ${item.quantity}',
                  style: TextStyle(fontSize: 14, color: theme.secondaryLabel),
                ),
              ],
            ),
          ),
          CupertinoButton(
            padding: EdgeInsets.zero,
            onPressed: onRemove,
            child: Icon(
              CupertinoIcons.trash,
              color: CupertinoColors.systemRed,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }
}

class _QuantityPicker extends StatelessWidget {
  final int quantity;
  final CustomTheme theme;
  final Function(int) onChanged;

  const _QuantityPicker({
    required this.quantity,
    required this.theme,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        CupertinoButton(
          padding: const EdgeInsets.all(8),
          onPressed: quantity > 0 ? () => onChanged(quantity - 1) : null,
          child: Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: quantity > 0 ? theme.primary : theme.quaternaryLabel,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              CupertinoIcons.minus,
              color: CupertinoColors.white,
              size: 16,
            ),
          ),
        ),

        Container(
          width: 40,
          child: Text(
            '$quantity',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: theme.label,
            ),
            textAlign: TextAlign.center,
          ),
        ),

        CupertinoButton(
          padding: const EdgeInsets.all(8),
          onPressed: quantity < 10 ? () => onChanged(quantity + 1) : null,
          child: Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: quantity < 10 ? theme.primary : theme.quaternaryLabel,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              CupertinoIcons.add,
              color: CupertinoColors.white,
              size: 16,
            ),
          ),
        ),
      ],
    );
  }
}
