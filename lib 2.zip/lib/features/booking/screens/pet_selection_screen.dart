import 'package:flutter/cupertino.dart';
import '../../../models/pet_info.dart';
import '../../../theme/theme_manager.dart';
import '../../../theme/app_theme.dart';

class PetSelectionScreen extends StatefulWidget {
  final PetInfo? initialPetInfo;
  final Function(PetInfo?) onPetSelected;

  const PetSelectionScreen({
    super.key,
    this.initialPetInfo,
    required this.onPetSelected,
  });

  @override
  State<PetSelectionScreen> createState() => _PetSelectionScreenState();
}

class _PetSelectionScreenState extends State<PetSelectionScreen> {
  bool _hasPet = false;
  PetSize _selectedSize = PetSize.small;
  final TextEditingController _breedController = TextEditingController();
  bool _needsSeat = false;
  bool _inCarrier = false;
  bool _onLap = false;

  @override
  void initState() {
    super.initState();
    if (widget.initialPetInfo != null) {
      _hasPet = true;
      _selectedSize = widget.initialPetInfo!.size;
      _breedController.text = widget.initialPetInfo!.breed;
      _needsSeat = widget.initialPetInfo!.needsSeat;
      _inCarrier = widget.initialPetInfo!.inCarrier;
      _onLap = widget.initialPetInfo!.onLap;
    }
  }

  @override
  void dispose() {
    _breedController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeManager = context.themeManager;
    final theme = themeManager.currentTheme;

    return CupertinoPageScaffold(
      backgroundColor: theme.systemBackground,
      navigationBar: CupertinoNavigationBar(
        backgroundColor: theme.secondarySystemBackground,
        middle: Text(
          'Перевозка животных',
          style: TextStyle(color: theme.label),
        ),
        leading: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: () => Navigator.of(context).pop(),
          child: Icon(CupertinoIcons.back, color: theme.primary),
        ),
        trailing: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: _savePetInfo,
          child: Text(
            'Готово',
            style: TextStyle(color: theme.primary, fontWeight: FontWeight.w600),
          ),
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Заголовок
              Text(
                'Путешествуете с питомцем?',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: theme.label,
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 8),

              Text(
                'Укажите информацию о вашем питомце для комфортной поездки',
                style: TextStyle(fontSize: 16, color: theme.secondaryLabel),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 32),

              // Переключатель наличия питомца
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: theme.secondarySystemBackground,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Icon(CupertinoIcons.paw, color: theme.primary, size: 24),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'У меня есть питомец',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: theme.label,
                        ),
                      ),
                    ),
                    CupertinoSwitch(
                      value: _hasPet,
                      onChanged: (value) {
                        setState(() {
                          _hasPet = value;
                          if (!value) {
                            _resetPetInfo();
                          }
                        });
                      },
                      activeColor: theme.primary,
                    ),
                  ],
                ),
              ),

              if (_hasPet) ...[
                const SizedBox(height: 24),

                // Размер животного
                Text(
                  'Размер питомца',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: theme.label,
                  ),
                ),
                const SizedBox(height: 16),

                ...PetSize.values.map((size) {
                  final petInfo = PetInfo(size: size, breed: '');
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _PetSizeCard(
                      size: size,
                      isSelected: _selectedSize == size,
                      theme: theme,
                      onTap: () {
                        setState(() {
                          _selectedSize = size;
                          // Автоматически устанавливаем параметры для крупных собак
                          if (size == PetSize.large) {
                            _needsSeat = true;
                            _inCarrier = false;
                            _onLap = false;
                          }
                        });
                      },
                    ),
                  );
                }).toList(),

                const SizedBox(height: 24),

                // Порода
                Text(
                  'Порода питомца',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: theme.label,
                  ),
                ),
                const SizedBox(height: 16),

                CupertinoTextField(
                  controller: _breedController,
                  placeholder: 'Например: Лабрадор',
                  style: TextStyle(color: theme.label),
                  decoration: BoxDecoration(
                    color: theme.secondarySystemBackground,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: theme.separator),
                  ),
                  placeholderStyle: TextStyle(color: theme.placeholderText),
                  padding: const EdgeInsets.all(16),
                ),

                const SizedBox(height: 24),

                // Особенности перевозки
                Text(
                  'Особенности перевозки',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: theme.label,
                  ),
                ),
                const SizedBox(height: 16),

                // Нужно отдельное место
                if (_selectedSize !=
                    PetSize.large) // Для крупных собак автоматически
                  _OptionRow(
                    title: 'Нужно отдельное место',
                    subtitle: 'Питомец займёт место пассажира',
                    value: _needsSeat,
                    theme: theme,
                    onChanged: (value) {
                      setState(() {
                        _needsSeat = value;
                        if (value) {
                          _onLap = false;
                        }
                      });
                    },
                  ),

                const SizedBox(height: 12),

                // В переноске
                if (_selectedSize !=
                    PetSize.large) // Крупные собаки не помещаются в переноску
                  _OptionRow(
                    title: 'В переноске/сумке',
                    subtitle: 'Питомец будет в специальной переноске',
                    value: _inCarrier,
                    theme: theme,
                    onChanged: (value) {
                      setState(() {
                        _inCarrier = value;
                      });
                    },
                  ),

                const SizedBox(height: 12),

                // На коленях
                if (_selectedSize != PetSize.large && !_needsSeat)
                  _OptionRow(
                    title: 'На коленях у пассажира',
                    subtitle: 'Питомец будет сидеть на коленях',
                    value: _onLap,
                    theme: theme,
                    onChanged: (value) {
                      setState(() {
                        _onLap = value;
                      });
                    },
                  ),

                // Предупреждение для крупных собак
                if (_selectedSize == PetSize.large) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: CupertinoColors.systemOrange.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: CupertinoColors.systemOrange,
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          CupertinoIcons.exclamationmark_triangle_fill,
                          color: CupertinoColors.systemOrange,
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Для крупных собак рекомендуется индивидуальный трансфер',
                            style: TextStyle(
                              fontSize: 14,
                              color: theme.label,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 24),

                // Стоимость
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.secondarySystemBackground,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            CupertinoIcons.money_dollar_circle_fill,
                            color: theme.primary,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Стоимость перевозки',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: theme.label,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _getPriceDescription(),
                        style: TextStyle(
                          fontSize: 14,
                          color: theme.secondaryLabel,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Правила перевозки
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.secondarySystemBackground,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            CupertinoIcons.info_circle_fill,
                            color: CupertinoColors.systemBlue,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Правила перевозки',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: theme.label,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        '• Животное должно быть привито\n'
                        '• При себе необходимо иметь ветпаспорт\n'
                        '• Агрессивные животные не перевозятся\n'
                        '• Крупные собаки только в индивидуальных поездках\n'
                        '• Переноска должна быть надёжно закреплена',
                        style: TextStyle(
                          fontSize: 14,
                          color: theme.secondaryLabel,
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  void _resetPetInfo() {
    _selectedSize = PetSize.small;
    _breedController.clear();
    _needsSeat = false;
    _inCarrier = false;
    _onLap = false;
  }

  String _getPriceDescription() {
    if (!_hasPet) return 'Без доплаты';

    final petInfo = PetInfo(size: _selectedSize, breed: '');
    final price = petInfo.additionalPrice;

    if (price == 0) {
      return 'Только индивидуальный трансфер (крупные собаки)';
    } else {
      return 'Доплата: $price ₽';
    }
  }

  void _savePetInfo() {
    if (_hasPet) {
      if (_breedController.text.trim().isEmpty) {
        _showAlert('Укажите породу питомца');
        return;
      }

      final petInfo = PetInfo(
        size: _selectedSize,
        breed: _breedController.text.trim(),
        needsSeat: _needsSeat,
        inCarrier: _inCarrier,
        onLap: _onLap,
      );
      widget.onPetSelected(petInfo);
    } else {
      widget.onPetSelected(null);
    }

    Navigator.of(context).pop();
  }

  void _showAlert(String message) {
    showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text('Внимание'),
        content: Text(message),
        actions: [
          CupertinoDialogAction(
            child: const Text('OK'),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }
}

class _PetSizeCard extends StatelessWidget {
  final PetSize size;
  final bool isSelected;
  final CustomTheme theme;
  final VoidCallback onTap;

  const _PetSizeCard({
    required this.size,
    required this.isSelected,
    required this.theme,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final petInfo = PetInfo(size: size, breed: '');

    return CupertinoButton(
      padding: EdgeInsets.zero,
      onPressed: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: theme.secondarySystemBackground,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? theme.primary : theme.separator,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: isSelected
                    ? theme.primary.withOpacity(0.1)
                    : theme.systemBackground,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                CupertinoIcons.paw,
                color: isSelected ? theme.primary : theme.secondaryLabel,
                size: 20,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    petInfo.sizeDescription,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: theme.label,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _getSizeExamples(),
                    style: TextStyle(fontSize: 14, color: theme.secondaryLabel),
                  ),
                ],
              ),
            ),
            if (petInfo.additionalPrice > 0)
              Text(
                '+${petInfo.additionalPrice} ₽',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: theme.primary,
                ),
              )
            else if (size == PetSize.large)
              Text(
                'Только инд.',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: CupertinoColors.systemOrange,
                ),
              ),
            const SizedBox(width: 8),
            Icon(
              isSelected
                  ? CupertinoIcons.checkmark_circle_fill
                  : CupertinoIcons.circle,
              color: isSelected ? theme.primary : theme.quaternaryLabel,
              size: 24,
            ),
          ],
        ),
      ),
    );
  }

  String _getSizeExamples() {
    switch (size) {
      case PetSize.tiny:
        return 'Чихуахуа, йоркширский терьер, померанский шпиц';
      case PetSize.small:
        return 'Корги, французский бульдог, такса';
      case PetSize.standard:
        return 'Кокер-спаниель, бигль, шелти';
      case PetSize.large:
        return 'Немецкая овчарка, лабрадор, ротвейлер';
    }
  }
}

class _OptionRow extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool value;
  final CustomTheme theme;
  final Function(bool) onChanged;

  const _OptionRow({
    required this.title,
    required this.subtitle,
    required this.value,
    required this.theme,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.secondarySystemBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: value ? theme.primary : theme.separator,
          width: value ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: theme.label,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 14, color: theme.secondaryLabel),
                ),
              ],
            ),
          ),
          CupertinoSwitch(
            value: value,
            onChanged: onChanged,
            activeColor: theme.primary,
          ),
        ],
      ),
    );
  }
}
