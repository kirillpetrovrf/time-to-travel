/// Размеры животных для тарификации
enum PetSize {
  tiny, // Той-породы, карликовые
  small, // Мелкие породы
  standard, // Стандартные породы
  large, // Крупные породы (овчарки, лабрадоры)
}

/// Информация о животном
class PetInfo {
  final PetSize size;
  final String breed;
  final bool needsSeat; // Нужно ли отдельное место
  final bool inCarrier; // В переноске/сумке
  final bool onLap; // На коленях

  const PetInfo({
    required this.size,
    required this.breed,
    this.needsSeat = false,
    this.inCarrier = false,
    this.onLap = false,
  });

  /// Получение описания размера
  String get sizeDescription {
    switch (size) {
      case PetSize.tiny:
        return 'Той-порода, карликовая';
      case PetSize.small:
        return 'Мелкая порода';
      case PetSize.standard:
        return 'Стандартная порода';
      case PetSize.large:
        return 'Крупная порода';
    }
  }

  /// Получение доплаты за животное
  int get additionalPrice {
    switch (size) {
      case PetSize.tiny:
      case PetSize.small:
        return 500; // +500₽ для маленьких пород
      case PetSize.standard:
        return 500; // +500₽ для стандартных пород
      case PetSize.large:
        return 0; // Только индивидуальный трансфер (цена уже другая)
    }
  }

  /// Требует ли индивидуального трансфера
  bool get requiresIndividualTransfer {
    return size == PetSize.large;
  }

  /// Описание размещения животного
  String get placementDescription {
    if (inCarrier) return 'В переноске';
    if (onLap) return 'На коленях';
    if (needsSeat) return 'Отдельное место';
    return 'Рядом с владельцем';
  }

  /// Конвертация в Map для сохранения в Firestore
  Map<String, dynamic> toJson() {
    return {
      'size': size.toString(),
      'breed': breed,
      'needsSeat': needsSeat,
      'inCarrier': inCarrier,
      'onLap': onLap,
    };
  }

  /// Создание из Map из Firestore
  factory PetInfo.fromJson(Map<String, dynamic> json) {
    return PetInfo(
      size: PetSize.values.firstWhere(
        (e) => e.toString() == json['size'],
        orElse: () => PetSize.small,
      ),
      breed: json['breed'] ?? '',
      needsSeat: json['needsSeat'] ?? false,
      inCarrier: json['inCarrier'] ?? false,
      onLap: json['onLap'] ?? false,
    );
  }

  @override
  String toString() {
    return 'PetInfo(size: $size, breed: $breed, placement: $placementDescription)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is PetInfo &&
        other.size == size &&
        other.breed == breed &&
        other.needsSeat == needsSeat &&
        other.inCarrier == inCarrier &&
        other.onLap == onLap;
  }

  @override
  int get hashCode {
    return Object.hash(size, breed, needsSeat, inCarrier, onLap);
  }

  /// Создание копии с изменениями
  PetInfo copyWith({
    PetSize? size,
    String? breed,
    bool? needsSeat,
    bool? inCarrier,
    bool? onLap,
  }) {
    return PetInfo(
      size: size ?? this.size,
      breed: breed ?? this.breed,
      needsSeat: needsSeat ?? this.needsSeat,
      inCarrier: inCarrier ?? this.inCarrier,
      onLap: onLap ?? this.onLap,
    );
  }
}

/// Константы для крупных пород
class LargeDogBreeds {
  static const List<String> breeds = [
    'Немецкая овчарка',
    'Лабрадор',
    'Ретривер',
    'Ротвейлер',
    'Доберман',
    'Алабай',
    'Кавказская овчарка',
    'Хаски',
    'Маламут',
    'Сенбернар',
    'Другая крупная порода',
  ];

  /// Проверка, является ли порода крупной
  static bool isLargeBreed(String breed) {
    return breeds.any((b) => breed.toLowerCase().contains(b.toLowerCase()));
  }
}

/// Правила перевозки животных
class PetTransportRules {
  /// Цена индивидуального трансфера с крупной собакой (включая химчистку)
  static const int largeDogsIndividualPrice = 10000;

  /// Обычная цена индивидуального трансфера
  static const int regularIndividualPrice = 8000;

  /// Доплата за маленьких животных
  static const int smallPetsAdditionalPrice = 500;

  /// Получение итоговой цены с учётом животных
  static int calculatePriceWithPets(
    int basePrice,
    List<PetInfo> pets,
    bool isIndividualTransfer,
  ) {
    if (pets.isEmpty) return basePrice;

    // Проверяем наличие крупных животных
    final hasLargePets = pets.any((pet) => pet.size == PetSize.large);

    if (hasLargePets) {
      // Если есть крупные животные, только индивидуальный трансфер
      return largeDogsIndividualPrice;
    }

    // Считаем доплату за маленьких животных
    final smallPetsCount = pets
        .where((pet) => pet.size != PetSize.large)
        .length;
    final additionalPrice = smallPetsCount * smallPetsAdditionalPrice;

    return basePrice + additionalPrice;
  }

  /// Проверка возможности групповой поездки с животными
  static bool canTravelInGroup(List<PetInfo> pets) {
    return !pets.any((pet) => pet.size == PetSize.large);
  }

  /// Получение сообщения о необходимости индивидуального трансфера
  static String? getIndividualTransferMessage(List<PetInfo> pets) {
    final largePets = pets.where((pet) => pet.size == PetSize.large);
    if (largePets.isNotEmpty) {
      return 'Для крупных собак доступен только индивидуальный трансфер (10,000₽) с обязательной химчисткой.';
    }
    return null;
  }
}
