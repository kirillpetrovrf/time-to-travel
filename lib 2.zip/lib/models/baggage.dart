/// Размеры багажа
enum BaggageSize {
  small, // S: 30×40 см (рюкзак)
  medium, // M: 50×60 см (спортивная сумка)
  large, // L: 70×80 см (чемодан)
  custom, // Пользовательский размер
}

/// Модель единицы багажа
class BaggageItem {
  final BaggageSize size;
  final int quantity;
  final String? customDescription; // Для размера "custom"
  final String? customDimensions; // "Д×Ш×В см" для размера "custom"

  const BaggageItem({
    required this.size,
    required this.quantity,
    this.customDescription,
    this.customDimensions,
  });

  /// Получение описания размера
  String get sizeDescription {
    switch (size) {
      case BaggageSize.small:
        return 'Рюкзак (S: 30×40 см)';
      case BaggageSize.medium:
        return 'Спортивная сумка (M: 50×60 см)';
      case BaggageSize.large:
        return 'Чемодан (L: 70×80 см)';
      case BaggageSize.custom:
        return customDescription ?? 'Другое';
    }
  }

  /// Получение габаритов
  String get dimensions {
    switch (size) {
      case BaggageSize.small:
        return '30×40 см';
      case BaggageSize.medium:
        return '50×60 см';
      case BaggageSize.large:
        return '70×80 см';
      case BaggageSize.custom:
        return customDimensions ?? 'Не указано';
    }
  }

  /// Получение приблизительного объёма для расчёта места в багажнике
  double get volumeScore {
    switch (size) {
      case BaggageSize.small:
        return 1.0 * quantity;
      case BaggageSize.medium:
        return 2.5 * quantity;
      case BaggageSize.large:
        return 4.0 * quantity;
      case BaggageSize.custom:
        // Для пользовательского размера считаем как средний
        return 2.5 * quantity;
    }
  }

  /// Конвертация в Map для сохранения
  Map<String, dynamic> toJson() {
    return {
      'size': size.name,
      'quantity': quantity,
      'customDescription': customDescription,
      'customDimensions': customDimensions,
    };
  }

  /// Создание из Map
  factory BaggageItem.fromJson(Map<String, dynamic> json) {
    return BaggageItem(
      size: BaggageSize.values.firstWhere(
        (e) => e.name == json['size'],
        orElse: () => BaggageSize.small,
      ),
      quantity: json['quantity'] ?? 0,
      customDescription: json['customDescription'],
      customDimensions: json['customDimensions'],
    );
  }

  @override
  String toString() {
    if (quantity == 0) return '';
    return '$quantity × $sizeDescription';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is BaggageItem &&
        other.size == size &&
        other.quantity == quantity &&
        other.customDescription == customDescription &&
        other.customDimensions == customDimensions;
  }

  @override
  int get hashCode {
    return size.hashCode ^
        quantity.hashCode ^
        customDescription.hashCode ^
        customDimensions.hashCode;
  }
}

/// Утилиты для работы с багажом
class BaggageUtils {
  /// Стандартные типы багажа для быстрого выбора
  static const List<BaggageSize> standardSizes = [
    BaggageSize.small,
    BaggageSize.medium,
    BaggageSize.large,
  ];

  /// Получение общего объёма багажа для группы пассажиров
  static double getTotalBaggageVolume(List<BaggageItem> baggageList) {
    return baggageList.fold(0.0, (total, item) => total + item.volumeScore);
  }

  /// Проверка, поместится ли багаж в стандартный багажник
  /// (условное максимальное значение для одной машины)
  static bool fitsInStandardTrunk(List<BaggageItem> baggageList) {
    const double maxTrunkVolume = 15.0; // Условные единицы объёма
    return getTotalBaggageVolume(baggageList) <= maxTrunkVolume;
  }

  /// Создание пустого багажа
  static List<BaggageItem> createEmptyBaggage() {
    return standardSizes
        .map((size) => BaggageItem(size: size, quantity: 0))
        .toList();
  }

  /// Формирование краткого описания багажа для отображения
  static String formatBaggageSummary(List<BaggageItem> baggageList) {
    final nonEmptyItems = baggageList.where((item) => item.quantity > 0);

    if (nonEmptyItems.isEmpty) {
      return 'Без багажа';
    }

    final descriptions = nonEmptyItems.map((item) => item.toString());
    return descriptions.join(', ');
  }
}
