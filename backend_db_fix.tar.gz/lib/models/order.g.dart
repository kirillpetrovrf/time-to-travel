// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'order.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Passenger _$PassengerFromJson(Map<String, dynamic> json) => Passenger(
  name: json['name'] as String?,
  age: (json['age'] as num?)?.toInt(),
  type: json['type'] as String?,
  seatType: json['seatType'] as String?,
  useOwnSeat: json['useOwnSeat'] as bool?,
  ageMonths: (json['ageMonths'] as num?)?.toInt(),
);

Map<String, dynamic> _$PassengerToJson(Passenger instance) => <String, dynamic>{
  'name': instance.name,
  'age': instance.age,
  'type': instance.type,
  'seatType': instance.seatType,
  'useOwnSeat': instance.useOwnSeat,
  'ageMonths': instance.ageMonths,
};

Baggage _$BaggageFromJson(Map<String, dynamic> json) => Baggage(
  type: json['type'] as String?,
  size: json['size'] as String?,
  count: (json['count'] as num?)?.toInt(),
  quantity: (json['quantity'] as num?)?.toInt(),
  pricePerExtraItem: (json['pricePerExtraItem'] as num?)?.toDouble(),
  customDescription: json['customDescription'] as String?,
);

Map<String, dynamic> _$BaggageToJson(Baggage instance) => <String, dynamic>{
  'type': instance.type,
  'size': instance.size,
  'count': instance.count,
  'quantity': instance.quantity,
  'pricePerExtraItem': instance.pricePerExtraItem,
  'customDescription': instance.customDescription,
};

Pet _$PetFromJson(Map<String, dynamic> json) => Pet(
  type: json['type'] as String?,
  name: json['name'] as String?,
  weight: (json['weight'] as num?)?.toDouble(),
  category: json['category'] as String?,
  breed: json['breed'] as String?,
  cost: (json['cost'] as num?)?.toDouble(),
  description: json['description'] as String?,
);

Map<String, dynamic> _$PetToJson(Pet instance) => <String, dynamic>{
  'type': instance.type,
  'name': instance.name,
  'weight': instance.weight,
  'category': instance.category,
  'breed': instance.breed,
  'cost': instance.cost,
  'description': instance.description,
};

Order _$OrderFromJson(Map<String, dynamic> json) => Order(
  id: json['id'] as String,
  orderId: json['orderId'] as String,
  userId: json['userId'] as String?,
  fromLat: (json['fromLat'] as num?)?.toDouble(),
  fromLon: (json['fromLon'] as num?)?.toDouble(),
  toLat: (json['toLat'] as num?)?.toDouble(),
  toLon: (json['toLon'] as num?)?.toDouble(),
  fromAddress: json['fromAddress'] as String,
  toAddress: json['toAddress'] as String,
  distanceKm: (json['distanceKm'] as num?)?.toDouble(),
  rawPrice: (json['rawPrice'] as num?)?.toDouble(),
  finalPrice: (json['finalPrice'] as num).toDouble(),
  baseCost: (json['baseCost'] as num?)?.toDouble(),
  costPerKm: (json['costPerKm'] as num?)?.toDouble(),
  status: $enumDecode(_$OrderStatusEnumMap, json['status']),
  clientName: json['clientName'] as String?,
  clientPhone: json['clientPhone'] as String?,
  departureDate: json['departureDate'] == null
      ? null
      : DateTime.parse(json['departureDate'] as String),
  departureTime: json['departureTime'] as String?,
  passengers: (json['passengers'] as List<dynamic>?)
      ?.map((e) => Passenger.fromJson(e as Map<String, dynamic>))
      .toList(),
  baggage: (json['baggage'] as List<dynamic>?)
      ?.map((e) => Baggage.fromJson(e as Map<String, dynamic>))
      .toList(),
  pets: (json['pets'] as List<dynamic>?)
      ?.map((e) => Pet.fromJson(e as Map<String, dynamic>))
      .toList(),
  notes: json['notes'] as String?,
  vehicleClass: $enumDecodeNullable(
    _$VehicleClassEnumMap,
    json['vehicleClass'],
  ),
  tripType: $enumDecodeNullable(_$TripTypeEnumMap, json['tripType']),
  direction: $enumDecodeNullable(_$DirectionEnumMap, json['direction']),
  createdAt: DateTime.parse(json['createdAt'] as String),
  updatedAt: DateTime.parse(json['updatedAt'] as String),
);

Map<String, dynamic> _$OrderToJson(Order instance) => <String, dynamic>{
  'id': instance.id,
  'orderId': instance.orderId,
  'userId': instance.userId,
  'fromLat': instance.fromLat,
  'fromLon': instance.fromLon,
  'toLat': instance.toLat,
  'toLon': instance.toLon,
  'fromAddress': instance.fromAddress,
  'toAddress': instance.toAddress,
  'distanceKm': instance.distanceKm,
  'rawPrice': instance.rawPrice,
  'finalPrice': instance.finalPrice,
  'baseCost': instance.baseCost,
  'costPerKm': instance.costPerKm,
  'status': _$OrderStatusEnumMap[instance.status]!,
  'clientName': instance.clientName,
  'clientPhone': instance.clientPhone,
  'departureDate': instance.departureDate?.toIso8601String(),
  'departureTime': instance.departureTime,
  'passengers': instance.passengers,
  'baggage': instance.baggage,
  'pets': instance.pets,
  'notes': instance.notes,
  'vehicleClass': _$VehicleClassEnumMap[instance.vehicleClass],
  'tripType': _$TripTypeEnumMap[instance.tripType],
  'direction': _$DirectionEnumMap[instance.direction],
  'createdAt': instance.createdAt.toIso8601String(),
  'updatedAt': instance.updatedAt.toIso8601String(),
};

const _$OrderStatusEnumMap = {
  OrderStatus.pending: 'pending',
  OrderStatus.confirmed: 'confirmed',
  OrderStatus.inProgress: 'inProgress',
  OrderStatus.completed: 'completed',
  OrderStatus.cancelled: 'cancelled',
};

const _$VehicleClassEnumMap = {
  VehicleClass.economy: 'economy',
  VehicleClass.comfort: 'comfort',
  VehicleClass.business: 'business',
  VehicleClass.minivan: 'minivan',
};

const _$TripTypeEnumMap = {
  TripType.group: 'group',
  TripType.individual: 'individual',
  TripType.customRoute: 'customRoute',
};

const _$DirectionEnumMap = {
  Direction.donetskToRostov: 'donetskToRostov',
  Direction.rostovToDonetsk: 'rostovToDonetsk',
};

CreateOrderDto _$CreateOrderDtoFromJson(Map<String, dynamic> json) =>
    CreateOrderDto(
      fromLat: (json['fromLat'] as num?)?.toDouble(),
      fromLon: (json['fromLon'] as num?)?.toDouble(),
      toLat: (json['toLat'] as num?)?.toDouble(),
      toLon: (json['toLon'] as num?)?.toDouble(),
      fromAddress: json['fromAddress'] as String,
      toAddress: json['toAddress'] as String,
      distanceKm: (json['distanceKm'] as num?)?.toDouble(),
      rawPrice: (json['rawPrice'] as num?)?.toDouble(),
      finalPrice: (json['finalPrice'] as num).toDouble(),
      baseCost: (json['baseCost'] as num?)?.toDouble(),
      costPerKm: (json['costPerKm'] as num?)?.toDouble(),
      clientName: json['clientName'] as String?,
      clientPhone: json['clientPhone'] as String?,
      departureDate: json['departureDate'] == null
          ? null
          : DateTime.parse(json['departureDate'] as String),
      departureTime: json['departureTime'] as String?,
      passengers: (json['passengers'] as List<dynamic>?)
          ?.map((e) => Passenger.fromJson(e as Map<String, dynamic>))
          .toList(),
      baggage: (json['baggage'] as List<dynamic>?)
          ?.map((e) => Baggage.fromJson(e as Map<String, dynamic>))
          .toList(),
      pets: (json['pets'] as List<dynamic>?)
          ?.map((e) => Pet.fromJson(e as Map<String, dynamic>))
          .toList(),
      notes: json['notes'] as String?,
      vehicleClass: json['vehicleClass'] as String?,
      tripType: json['tripType'] as String?,
      direction: json['direction'] as String?,
    );

Map<String, dynamic> _$CreateOrderDtoToJson(CreateOrderDto instance) =>
    <String, dynamic>{
      'fromLat': instance.fromLat,
      'fromLon': instance.fromLon,
      'toLat': instance.toLat,
      'toLon': instance.toLon,
      'fromAddress': instance.fromAddress,
      'toAddress': instance.toAddress,
      'distanceKm': instance.distanceKm,
      'rawPrice': instance.rawPrice,
      'baseCost': instance.baseCost,
      'costPerKm': instance.costPerKm,
      'finalPrice': instance.finalPrice,
      'clientName': instance.clientName,
      'clientPhone': instance.clientPhone,
      'departureDate': instance.departureDate?.toIso8601String(),
      'departureTime': instance.departureTime,
      'passengers': instance.passengers,
      'baggage': instance.baggage,
      'pets': instance.pets,
      'notes': instance.notes,
      'vehicleClass': instance.vehicleClass,
      'tripType': instance.tripType,
      'direction': instance.direction,
    };

UpdateOrderDto _$UpdateOrderDtoFromJson(Map<String, dynamic> json) =>
    UpdateOrderDto(
      status: json['status'] as String?,
      clientName: json['clientName'] as String?,
      clientPhone: json['clientPhone'] as String?,
      departureDate: json['departureDate'] == null
          ? null
          : DateTime.parse(json['departureDate'] as String),
      departureTime: json['departureTime'] as String?,
      passengers: (json['passengers'] as List<dynamic>?)
          ?.map((e) => Passenger.fromJson(e as Map<String, dynamic>))
          .toList(),
      baggage: (json['baggage'] as List<dynamic>?)
          ?.map((e) => Baggage.fromJson(e as Map<String, dynamic>))
          .toList(),
      pets: (json['pets'] as List<dynamic>?)
          ?.map((e) => Pet.fromJson(e as Map<String, dynamic>))
          .toList(),
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$UpdateOrderDtoToJson(UpdateOrderDto instance) =>
    <String, dynamic>{
      'status': instance.status,
      'clientName': instance.clientName,
      'clientPhone': instance.clientPhone,
      'departureDate': instance.departureDate?.toIso8601String(),
      'departureTime': instance.departureTime,
      'passengers': instance.passengers,
      'baggage': instance.baggage,
      'pets': instance.pets,
      'notes': instance.notes,
    };
