import 'dart:convert';
import 'package:dart_frog/dart_frog.dart';
import 'package:backend/services/database_service.dart';
import 'package:backend/services/telegram_bot_service.dart';
import 'package:backend/repositories/user_repository.dart';
import 'package:logging/logging.dart';

final _log = Logger('TelegramWebhook');

/// Обработчик Telegram webhook
Future<Response> onRequest(RequestContext context) async {
  if (context.request.method != HttpMethod.post) {
    return Response(statusCode: 405, body: 'Method Not Allowed');
  }

  try {
    final body = await context.request.body();
    final update = jsonDecode(body) as Map<String, dynamic>;

    _log.info('📱 Получено обновление от Telegram');

    // Получаем сервисы из контекста
    final db = context.read<DatabaseService>();
    final userRepo = UserRepository(db);
    final telegramBot = context.read<TelegramBotService>();

    // Обработка сообщения
    if (update['message'] != null) {
      final message = update['message'] as Map<String, dynamic>;
      final text = message['text'] as String?;
      final from = message['from'] as Map<String, dynamic>;
      final chatId = from['id'] as int;

      if (text != null && text.startsWith('/start')) {
        await _handleStartCommand(
          text: text,
          chatId: chatId,
          from: from,
          userRepo: userRepo,
          telegramBot: telegramBot,
        );
      }
    }

    return Response(statusCode: 200, body: 'OK');
  } catch (e, stackTrace) {
    _log.severe('❌ Ошибка обработки webhook: $e', e, stackTrace);
    return Response(statusCode: 500, body: 'Internal Server Error');
  }
}

/// Обработка команды /start
Future<void> _handleStartCommand({
  required String text,
  required int chatId,
  required Map<String, dynamic> from,
  required UserRepository userRepo,
  required TelegramBotService telegramBot,
}) async {
  final telegramId = chatId;
  final firstName = from['first_name'] as String?;
  final lastName = from['last_name'] as String?;
  final username = from['username'] as String?;

  // Проверяем есть ли параметр (deep link)
  final parts = text.split(' ');
  String? authCode;
  String? phone;

  if (parts.length > 1) {
    authCode = parts[1]; // например: AUTH_79281234567
    
    if (authCode.startsWith('AUTH_')) {
      phone = '+${authCode.substring(5)}'; // Убираем AUTH_
      _log.info('🔑 Deep link авторизация: $authCode, phone: $phone');
    }
  }

  try {
    // Создаём или обновляем пользователя
    final user = await userRepo.upsertFromTelegram(
      telegramId: telegramId,
      phone: phone,
      firstName: firstName,
      lastName: lastName,
      username: username,
    );

    _log.info('✅ Пользователь обработан: ${user.id}');

    // Если это авторизация через deep link
    if (authCode != null) {
      // Сохраняем статус авторизации (для polling)
      // TODO: Сохранить в Redis или временную таблицу
      // authSessions[authCode] = {userId: user.id, status: 'success'}

      // Отправляем приветствие
      await telegramBot.sendMessage(
        chatId: chatId,
        text: '''
🎉 <b>Добро пожаловать в TimeToTravel!</b>

Вы успешно авторизовались!

Теперь можете вернуться в приложение и начать пользоваться сервисом.

👉 Закройте Telegram и откройте приложение
''',
      );
    } else {
      // Обычный /start без параметров
      final greeting = user.isDispatcher
          ? '''
👋 Здравствуйте, <b>${user.fullName}</b>!

Вы зашли как <b>Диспетчер</b>.

📱 Откройте приложение Time To Travel для управления заказами.
'''
          : '''
👋 Здравствуйте, <b>${user.fullName}</b>!

Добро пожаловать в TimeToTravel!

🚗 Откройте приложение для бронирования поездок.
''';

      await telegramBot.sendMessage(chatId: chatId, text: greeting);
    }
  } catch (e) {
    _log.severe('❌ Ошибка обработки /start: $e');
    
    await telegramBot.sendMessage(
      chatId: chatId,
      text: '❌ Произошла ошибка. Попробуйте позже.',
    );
  }
}
